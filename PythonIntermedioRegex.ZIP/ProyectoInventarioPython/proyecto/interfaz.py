import tkinter as  tk
from tkinter import ttk
from tkinter.ttk import  Label, Entry, Button
from tkinter import StringVar, DoubleVar, IntVar
from tkinter import END
from tkinter.messagebox import showinfo, showwarning

# Vista
class InventarioView(ttk.Frame):
    """
    Vista principal del sistema de inventario. Maneja la interfaz gráfica y la interacción con el controlador.

    :param root: La ventana raíz de la aplicación.
    :type root: tk.Tk
    :param controller: El controlador que gestiona la lógica de negocio.
    :type controller: ControladorInventario 
    """
    
    def __init__(self, root, controller):
        """
        Inicializa el  InventarioView.

        Args:
            root (tk.Tk): La ventana raiz de la aplicacionThe root window of the application.
            controller (InventarioController): El controlador responsable de la logica.
        """
        super().__init__(root)
        
        self.controller = controller
        
        self.root = root
        self.root.title("Sistema de Inventario ")

        # --- Configuración del Grid Principal ---
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)
        
        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.root)
        frame1.grid(row=0, column=0, sticky="new", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.columnconfigure(1,weight=1)
        frame1.columnconfigure(2,weight=2)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)
        frame1.rowconfigure(2,weight=1)
        frame1.rowconfigure(3,weight=1)
        frame1.rowconfigure(4,weight=1)
        
        # Frame 2: va ubicado en el ultimo row de Frame1 y es para los botones
        frame2 = ttk.Frame(frame1)
        frame2.grid(row=4, column=0,columnspan=4,sticky="nsew", padx=5, pady=5)
        frame2.columnconfigure(0,weight=1)
        frame2.columnconfigure(1,weight=1)
        frame2.columnconfigure(2,weight=1)
        frame2.columnconfigure(3,weight=1)
        frame2.columnconfigure(4,weight=1)
        frame2.columnconfigure(5,weight=1)
        frame2.columnconfigure(6,weight=1)
        frame2.rowconfigure(0,weight=1)

        # Frame 3: es para el item list de elementos,
        frame3 = ttk.Frame(self.root)
        frame3.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        frame3.columnconfigure(0,weight=1)
        frame3.rowconfigure(0,weight=1)

        # --- Etiquetas y campos de entrada --
        # Etiqueta y campo para el id
        id_label = ttk.Label(frame1, text="ID:")
        id_label.grid(row=0, column=0, padx=5, pady=10)
        self.id_entry = ttk.Entry(frame1)
        self.id_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Etiqueta y campo para el Marca
        marca_label = ttk.Label(frame1, text="Marca:")
        marca_label.grid(row=1, column=0, padx=5, pady=5)
        self.marca_entry = ttk.Entry(frame1)
        self.marca_entry.grid(row=1, column=1, padx=5, pady=5)

        # Etiqueta y campo para el Modelo
        modelo_label = ttk.Label(frame1, text="Modelo:")
        modelo_label.grid(row=2, column=0, padx=5, pady=5)
        self.modelo_entry = ttk.Entry(frame1)
        self.modelo_entry.grid(row=2, column=1, padx=5, pady=5)

        # Etiqueta y campo para la cantidad
        cantidad_label = ttk.Label(frame1, text="Cantidad:")
        cantidad_label.grid(row=3, column=0, padx=5, pady=5)
        self.cantidad_entry = ttk.Entry(frame1)
        self.cantidad_entry.grid(row=3, column=1, padx=5, pady=5)

        # --- Botones ---
        # Boton Agregar
        agregar_button = ttk.Button(frame2, text="Agregar", command=lambda:[self.agregar_registro(self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        agregar_button.grid(row=0, column=0, padx=5, pady=5)

        # Boton Eliminar
        eliminar_button = ttk.Button(frame2, text="Eliminar", command=lambda:[self.eliminar_registro(self.id_entry.get())])
        eliminar_button.grid(row=0, column=1, padx=5, pady=5)

        # Boton Modificar
        modificar_button = ttk.Button(frame2, text="Modificar", command=lambda:[self.modificar_registro(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        modificar_button.grid(row=0, column=2, padx=5, pady=5)

        # Boton Consultar
        consultar_button = ttk.Button(frame2, text="Consultar", command=lambda:[self.consultar_registros(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        consultar_button.grid(row=0, column=3, padx=5, pady=5)
        
        # Boton Exportar
        exportar_button = ttk.Button(frame2, text="Exportar", command=lambda:[self.exportar_registros(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        exportar_button.grid(row=0, column=4, padx=5, pady=5)
        
        # Boton Limiar Campos
        limpiar_button = ttk.Button(frame2, text="Limpiar", command=lambda:[self.limpiar_campos()])
        limpiar_button.grid(row=0, column=5, padx=5, pady=5)
        
        # Boton Cambiar Tema
        self.theme_button = ttk.Button(frame2, text="Cambiar Theme")
        self.theme_button.grid(row=0, column=6, padx=5, pady=5)
        self.theme_button.bind("<Button-1>", self.mostrar_menu) 

        self.theme_menu = tk.Menu(self.root, tearoff=0)
        for theme_name in self.root.get_themes():
            self.theme_menu.add_command(label=theme_name, command=lambda t=theme_name: self.change_theme(t))

        # --- Treeview ---
        self.treeview = ttk.Treeview(frame3, columns=("ID", "Marca", "Modelo", "Cantidad"), show="headings")
        self.treeview.heading("ID", text="ID")
        self.treeview.heading("Marca", text="Marca")
        self.treeview.heading("Modelo", text="Modelo")
        self.treeview.heading("Cantidad", text="Cantidad")
        self.treeview.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # Vincular evento de selección en el treevew
        self.treeview.bind("<<TreeviewSelect>>", self.on_tree_select)
        
        # Actualizar el treeview
        self.actualizar_view(self.treeview)
        
    
        
    def change_theme(self, theme):
        """
        Cambiar el tema de la aplicacion.

        Args:
            theme (str): El nombre del tema a aplicar 
        """
        self.root.set_theme(theme)

    def mostrar_menu(self, event):
        """
        Muestra el menu de contexto para la seleccion de tema

        Args:
            event (tk.Event): El evento que acciona el display del menu.
        """
        try:
            self.theme_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.theme_menu.grab_release()

    def on_tree_select(self, event):
        """
        Se encarga se la seleccion de un item en el Treeview
        
        Este metodo es llamado cuando un item en el Treeview es seleccionado. Este llena los
        calores de los campos Entry con los datos del item seleccionado. 

        Args:
            event (tk.Event): El evento que acciona la seleccion
        """
        #Cuando esta en 'bind' un evento es accionado por diferentes motivos, no solo cuando es seleccionado,
        #Tambien se activa cuando se deselecciona por actualizar, o agregar elementos, eso genera un error o warning, pues deja de encontrarlo
        #Para evitar este error se agrega un try
        try:
            
            item = self.treeview.selection()[0]
            values = self.treeview.item(item, "values")
            self.id_entry.delete(0, tk.END)
            self.id_entry.insert(0, values[0])
            self.marca_entry.delete(0, tk.END)
            self.marca_entry.insert(0, values[1])
            self.modelo_entry.delete(0, tk.END)
            self.modelo_entry.insert(0, values[2])
            self.cantidad_entry.delete(0, tk.END)
            self.cantidad_entry.insert(0, values[3])
        except Exception as e:
            print(f"Debido a cambios en las listas, la seleccion anterior se deselecciono de la lista")

    def agregar_registro(self, marca, modelo, cantidad):
        """
        Agrega un registro nuevo al inventario
        Add a new inventory record.

        Args:
            marca (str): La marca del nuevo item.
            modelo (str): El modelo del nuevo item.
            cantidad (int): La cantidad del nuevo item.
        """
        respuesta = self.controller.agregar_registro(marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "agregar")

    def eliminar_registro(self, id):
        """
        Elimina un registro del inventario

        Args:
            id (int): El ID del registro a eliminar
        """
        respuesta = self.controller.eliminar_registro(id)
        self.handle_respuesta(respuesta, "eliminar")    
          
        
    def modificar_registro(self, id, marca, modelo, cantidad):
        """
        Modifica un registro existente en el inventario.

        :param id: El ID del registro a modificar.
        :param marca: La nueva marca del producto.
        :param modelo: El nuevo modelo del producto.
        :param cantidad: La nueva cantidad en inventario.
        """
        respuesta = self.controller.modificar_registro(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "modificar")

    def consultar_registros(self, id, marca, modelo, cantidad):
        """
        Consulta registros en el inventario según los criterios especificados.

        :param id: El ID del registro a buscar (opcional).
        :param marca: La marca del producto a buscar (opcional).
        :param modelo: El modelo del producto a buscar (opcional).
        :param cantidad: La cantidad mínima en inventario a buscar (opcional).
        """
        respuesta = self.controller.consultar_registros(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "consultar")

    def exportar_registros(self, id, marca, modelo, cantidad):
        """
        Exporta los registros del inventario que cumplen los criterios especificados.

        :param id: El ID del registro a exportar (opcional).
        :param marca: La marca del producto a exportar (opcional).
        :param modelo: El modelo del producto a exportar (opcional).
        :param cantidad: La cantidad mínima en inventario a exportar (opcional).
        """
        respuesta = self.controller.exportar_registros(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "exportar")

    
    def handle_respuesta(self,respuesta,tipo):
        """
        Maneja la respuesta de una operación (agregar, modificar, eliminar, consultar, exportar).

        :param respuesta: Objeto de respuesta con información sobre el resultado de la operación.
        :param tipo: El tipo de operación realizada.
        """
        error = respuesta.get_error()
        if tipo == 'agregar':
            textoExito = "El registro se ha agregado con exito"
            textoFracaso = f"Ups! Algo salio mal al agregar el registro: {error}"
        elif tipo == 'modificar':
            textoExito = "El registro se ha modificado con exito"
            textoFracaso = f"Ups! Algo salio mal al modificar el registro: {error}"
        elif tipo == 'eliminar':
            textoExito = "El registro se ha eliminado con exito"
            textoFracaso = f"Ups! Algo salio mal al eliminar el registro: {error}"
        elif tipo == 'consultar':
            textoExito = "La consulta se ha realizado con exito"
            textoFracaso = f"Ups! Algo salio mal al realizar la consulta: {error}"
        elif tipo == 'exportar':
            textoExito = "Se han exportado los datos con exito"
            textoFracaso = f"Ups! Algo salio mal al exportar la consulta: {error}"
        else:
            textoExito = f"Algo anda mal, favor de contactar al desarrollador: {tipo} "
            textoFracaso = f"Ups! Algo salio mal al agregar el registro: {error}"
            
        if respuesta.get_status() == 1 :
            if tipo in ["consultar", "exportar"]:
                self.actualizar_view(self.treeview,respuesta.get_registros())
            else:
                self.actualizar_view(self.treeview)
            showinfo("Informacion",textoExito)
        else:
            showwarning("Advertencia!",textoFracaso)
    
    def limpiar_campos(self):
        """
        Limpia los campos de entrada de datos en la interfaz de usuario.
        """
        try:
            self.id_entry.delete(0, tk.END)
            self.marca_entry.delete(0, tk.END)
            self.modelo_entry.delete(0, tk.END)
            self.cantidad_entry.delete(0, tk.END)
        except Exception as e:
            print(f"No se pudieron Limpiar los campos {e}")
      
    
    def actualizar_view(self, tree, registros_nuevos = None):
        """
        Actualiza la vista del árbol (treeview) con los registros del inventario.

        :param tree: El widget Treeview a actualizar.
        :param registros_nuevos: Lista opcional de nuevos registros para mostrar. 
                                Si es None, se obtendrán los registros del controlador.
        """
        
        registros = tree.get_children()
        for registro in registros:
            tree.delete(registro)
        
        if registros_nuevos is None:
            registros_nuevos = self.controller.get_registros()
        
        for registro in registros_nuevos:
            tree.insert('', END, text="" ,values=(registro.id, registro.marca, registro.modelo, registro.cantidad))
