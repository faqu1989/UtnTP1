import random 
from peewee import *
from respuesta import Respuesta
import re
db = SqliteDatabase('inventariado.db')

# Modelo de Inventario
class InventarioModel:
    """
    Modelo para gestionar el inventario en una base de datos SQLite.

    Utiliza Peewee como ORM para interactuar con una base de datos SQLite.
    Este modelo proporciona métodos para agregar, modificar, eliminar y consultar registros de inventario.

    """  

    class Registro(Model):
        """
        Representa un registro individual en el inventario. Es necesario para la implementacion del ORM de peewee

        Atributos:
            id (AutoField): Identificador único del registro.
            marca (CharField): Marca del producto.
            modelo (CharField): Modelo del producto.
            cantidad (IntegerField): Cantidad disponible en el inventario.
        """
        
        id = AutoField(primary_key=True)
        marca = CharField()
        modelo = CharField()
        cantidad = IntegerField()

        class Meta:
            database = db

    def __init__(self):
        """
        Inicializa el modelo de inventario.

        Conecta a la base de datos y crea la tabla si no existe.
        """
        self.db = db
        self.crear_tabla()

    def crear_tabla(self):
        """
        Crea la tabla 'Registro' en la base de datos si no existe.
        """
        self.db.connect()
        self.db.create_tables([self.Registro])
        self.create_dummies()  # Para datos de prueba

    def get_respuesta_vacia(self):
        """
        Obtiene una instancia vacía de la clase Respuesta.

        Returns:
            Respuesta: Una instancia de Respuesta con valores por defecto.
        """
        return Respuesta()
    
    def agregar_registro(self, marca,modelo,cantidad):
        """
        Agrega un nuevo registro al inventario.

        Args:
            marca (str): Marca del producto.
            modelo (str): Modelo del producto.
            cantidad (int): Cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el nuevo registro.
        """
        respuesta = self.get_respuesta_vacia()

        # Validación de datos con expresiones regulares
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
               
        try:
            nuevo_registro =  self.Registro(marca = marca, modelo = modelo , cantidad = cantidad)
            nuevo_registro.save()
            respuesta.set_status(1)
            respuesta.append_registro(nuevo_registro)
        except Exception as e:
            respuesta.set_status(0)
            respuesta.append_registro(nuevo_registro) # Incluir el registro fallido en la respuesta en caso de que se desee utilizar
            respuesta.set_error(e)
        finally:
            return respuesta
    
    def modificar_registro(self,id,marca,modelo,cantidad):
        """
        Modifica un registro existente en el inventario.

        Args:
            id (int): ID del registro a modificar.
            marca (str): Nueva marca del producto.
            modelo (str): Nuevo modelo del producto.
            cantidad (int): Nueva cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el registro modificado.
        """
        respuesta = self.get_respuesta_vacia()
        
        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        try:
            registro = self.Registro.get_or_none(id = id)
            if registro:
                #El registro existe
                registro.marca = marca
                registro.modelo = modelo
                registro.cantidad = cantidad
                registro.save()
                respuesta.set_status(1)
                respuesta.append_registro(registro)
            else:
                #el registro no exsite
                respuesta.set_status(0)
                respuesta.set_error("Registro no existe")
        except Exception as e:
            respuesta.set_status(0)
            respuesta.append_registro(registro)# Incluir el registro fallido en la respuesta
            respuesta.set_error(e)
        finally:
            return respuesta
    
    def eliminar_registro(self,id):
        """
        Elimina un registro existente en el inventario.

        Args:
            id (int): ID del registro a modificar.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación
        """
        respuesta = self.get_respuesta_vacia()
        
        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        try:
            registro = self.Registro.get_or_none(id = id)
            if registro:
                registro.delete_instance()
                respuesta.set_status(1)
            else:
                respuesta.set_status(0)
                respuesta.set_error("Registro no existe")
        except Exception as e:
            respuesta.set_status(0)
            respuesta.set_error(e)
        finally:
            return respuesta
 
    def consultar_registros(self,id,marca,modelo,cantidad):
        """
        Realiza una consulta en el inventario, de acuerdo a los parametros de entrada.

        Args:
            id (int): ID del registro a modificar.
            marca (str): Nueva marca del producto.
            modelo (str): Nuevo modelo del producto.
            cantidad (int): Nueva cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el listado de los registros .
        """
        respuesta = self.get_respuesta_vacia()

        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        # REvisar que valores son vacios para hacerlos None 
        # Aquellos que sean None no seran utilizados para formar el query de consulta.
        if id =="":
            id = None
        if marca == "":
            marca = None
        if modelo == "":
            modelo = None
        if cantidad == "":
            cantidad = None
        
        query  = self.Registro.select() #Comienza con una consulta basica
        
        # Agregar condiciones si los valores no son nulos
        if id is not None:
            query = query.where(self.Registro.id == id)
            
        if marca is not None:
            query = query.where(self.Registro.marca == marca)
            
        if modelo is not None:
            query = query.where(self.Registro.modelo == modelo)
            
        if cantidad is not None:
            query = query.where(self.Registro.cantidad <= cantidad)
        registros = list(query)
        
        if len(registros) > 0:
            respuesta.set_status(1)
            respuesta.set_registros(registros)
        else:
            respuesta.set_error("No Se encontraron registros")
            
        return respuesta
   
    def create_dummies(self):
        """Crea registros de prueba (dummies) en la base de datos.

        Si hay menos de 10 registros existentes, se generan 15 registros aleatorios con marcas y modelos predefinidos.
        """
        registros = self.Registro.select()
        if len(registros) > 10:
            pass  # No se crean dummies si ya hay suficientes registros
        else:
            marcas = ["Apple", "Samsung", "Toyota", "Coca-Cola", "Nike", "Google", "Mercedes-Benz", "McDonald's", "Disney", "Adidas", "BMW", "Microsoft", "Intel", "Sony", "Louis Vuitton", "Honda", "Pepsi", "Zara", "Nescafé", "Nintendo"]
            modelos = ["iPhone 14", "Galaxy S23", "Corolla", "Mustang", "Air Force 1", "Pixel 7", "Clase C", "Big Mac", "Model 3", "Stan Smith", "Serie 3", "Surface Laptop", "Core i9", "PlayStation 5", "Neverfull", "Civic", "Aquafina", "AirPods Max", "Nespresso Vertuo", "Switch"]

            for i in range(15):
                registro_dummie = self.Registro(marca=random.choice(marcas), modelo=random.choice(modelos), cantidad=i)
                registro_dummie.save()

            print("Dummies creados")

    def get_registros(self):
        """Obtiene todos los registros de la base de datos.

        Returns:
            peewee.ModelSelect: Un objeto que representa la consulta para obtener los registros.
        """
        registros = self.Registro.select()
        return registros

    def checkRegex(self, marca, modelo, cantidad):
        """Valida los datos de marca, modelo y cantidad usando expresiones regulares.

        Args:
            marca (str): La marca del producto.
            modelo (str): El modelo del producto.
            cantidad (str): La cantidad del producto.

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        respuesta = {"status": True, "error": ""}
        patron_alfanumerico = r"^\s*[A-Za-z0-9 _-]{3,}\s*$"  # Patrón para valores alfanuméricos con al menos 3 caracteres
        if not marca == "":
            if not re.match(patron_alfanumerico, marca):
                respuesta["status"] = False
                respuesta["error"] = "El valor de la marca no es válido"
                return respuesta
        if not modelo == "":
            if not re.match(patron_alfanumerico, modelo):
                respuesta["status"] = False
                respuesta["error"] = "El valor del modelo no es válido"
                return respuesta

        check_cantidad = self.checkRegexNumber(cantidad)
        if check_cantidad["status"] == False:
            return check_cantidad

        return respuesta

    def checkRegexNumber(self, number):
        """Valida si un valor es numérico.

        Args:
            number (str): El valor a validar.

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """

            
        patron_numerico = r"^\d+$"  # Patrón para valores numéricos
        respuesta = {"status": True, "error": ""}

        if not number == "":
            if not re.match(patron_numerico, number):
                respuesta["status"] = False
                respuesta["error"] = "El valor numérico no es válido, solo se aceptan números"

        return respuesta