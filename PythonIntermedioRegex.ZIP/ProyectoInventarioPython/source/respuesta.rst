.. module:: respuesta

.. _respuesta:

Módulo respuesta
----------------


Clase que representa la respuesta de una operación, incluyendo estado, errores y registros.


Clase Respuesta
~~~~~~~~~~~~~~~

.. autoclass:: Respuesta
   :members:
   :undoc-members:
   :show-inheritance:

   .. automethod:: __init__



