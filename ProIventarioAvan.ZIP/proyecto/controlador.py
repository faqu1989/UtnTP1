from decorador_dev_log import dev_log
from servidor import Servidor
from respuesta import Respuesta
from validador import Validador

# Controlador 
class InventarioController:
    """
    Clase que maneja las operaciones de inventario, actuando como intermediario entre la interfaz de usuario y el modelo de datos.

    :param model: El modelo de datos que representa el inventario.
    :type model: InventarioModel (o una clase similar)
    """

    def __init__(self,cliente):
        self.cliente = cliente
        self.usuario = None
        self.tipo = None
        self.validador = Validador()
        self.socket=None
        self.socket_owner = False
        
    @dev_log({"clase":"InventarioController"})     
    def get_respuesta_vacia(self):
        """
        Obtiene una instancia vacía de la clase Respuesta.

        Returns:
            Respuesta: Una instancia de Respuesta con valores por defecto.
        """
        return Respuesta()
    
    @dev_log({"clase":"InventarioController"})
    def agregar_registro(self, marca, modelo, cantidad):
        """
        Agrega un nuevo registro al inventario.

        :param marca: La marca del producto.
        :type marca: str
        :param modelo: El modelo del producto.
        :type modelo: str
        :param cantidad: La cantidad disponible del producto.
        :type cantidad: int
        :return: El resultado de la operación de agregar (éxito/fracaso).
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()

        # Validación de datos con expresiones regulares
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        consulta = f"ACCION:AGREGAR<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>MARCA:{marca}<>MODELO:{modelo}<>CANTIDAD:{cantidad}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def checkRegex(self, marca, modelo, cantidad):
        """Valida los datos de marca, modelo y cantidad 
        Utiliza la clase Validador para realizar la validacion
        usando expresiones regulares.

        Args:
            marca (str): La marca del producto.
            modelo (str): El modelo del producto.
            cantidad (str): La cantidad del producto.

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        return self.validador.valida_cadenas_registro(marca,modelo,cantidad)

    @dev_log({"clase":"InventarioController"})
    def checkRegexNumber(self, number):
        """Valida si un valor es numérico.
        Utiliza la clase Validador para realizar la validacion

        Args:
            number (str): El valor a validar.
        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        return self.validador.valida_numero(number)
    
    @dev_log({"clase":"InventarioController"})
    def modificar_registro(self, id, marca, modelo, cantidad):
        """
        Modifica un registro existente en el inventario.

        :param id: El identificador único del registro a modificar.
        :type id: int
        :param marca: La nueva marca del producto.
        :type marca: str
        :param modelo: El nuevo modelo del producto.
        :type modelo: str
        :param cantidad: La nueva cantidad disponible del producto.
        :type cantidad: int
        :return: El resultado de la operación de modificar (éxito/fracaso).
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()
        
        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        consulta = f"ACCION:MODIFICAR<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>ID:{id}<>MARCA:{marca}<>MODELO:{modelo}<>CANTIDAD:{cantidad}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def eliminar_registro(self, id):
        """
        Elimina un registro del inventario.

        :param id: El identificador único del registro a eliminar.
        :type id: int
        :return: El resultado de la operación de eliminar (éxito/fracaso).
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()
        
        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        consulta = f"ACCION:ELIMINAR<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>ID:{id}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def consultar_registros(self, id="", marca="", modelo="", cantidad=""):  # Valores por defecto para filtros opcionales
        """
        Consulta los registros del inventario, permitiendo filtrar por ID, marca, modelo y/o cantidad.
        Si el valor de ID es ingresado filtra por ID,
        Si el valor de marca esta indicado, filtra por marca
        Si el valor de modelo esta indicado, filtra por modelo.
        SI el valor de candidad esta especificado, filtra por aquellso que sean menor o igual a la cantidad especidicada.
        
        
        :param id: (Opcional) El ID del registro a buscar.
        :type id: str
        :param marca: (Opcional) La marca del producto a buscar.
        :type marca: str
        :param modelo: (Opcional) El modelo del producto a buscar.
        :type modelo: str
        :param cantidad: (Opcional) La cantidad del producto a buscar.
        :type cantidad: str
        :return: El resultado de la consulta, incluyendo los registros encontrados y el estado de la operación.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()

        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        consulta = f"ACCION:CONSULTAR<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>ID:{id}<>MARCA:{marca}<>MODELO:{modelo}<>CANTIDAD:{cantidad}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def exportar_registros(self, id="", marca="", modelo="", cantidad=""):  # Valores por defecto para filtros opcionales
        """
        Exporta los registros del inventario a un archivo de texto, permitiendo filtrar por ID, marca, modelo y/o cantidad.
        Si el valor de ID es ingresado filtra por ID,
        Si el valor de marca esta indicado, filtra por marca
        Si el valor de modelo esta indicado, filtra por modelo.
        SI el valor de candidad esta especificado, filtra por aquellso que sean menor o igual a la cantidad especidicada.
        

        :param id: (Opcional) El ID del registro a buscar.
        :type id: str
        :param marca: (Opcional) La marca del producto a buscar.
        :type marca: str
        :param modelo: (Opcional) El modelo del producto a buscar.
        :type modelo: str
        :param cantidad: (Opcional) La cantidad del producto a buscar.
        :type cantidad: str
        :return: El resultado de la consulta, indicando si la exportación fue exitosa.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()

        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        consulta = f"ACCION:EXPORTAR<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>ID:{id}<>MARCA:{marca}<>MODELO:{modelo}<>CANTIDAD:{cantidad}"
        respuesta = self.cliente.consulta(consulta)
        
        if respuesta.get_status() == 1:
                            
            if id =="":
                id = "ID"
            if marca == "":
                marca = "MK"
            if modelo == "":
                modelo = "MD"
            if cantidad == "":
                cantidad = "QT"
            with open(f'inventariado_{id}_{marca}_{modelo}_{cantidad}.txt', 'w') as f:
                for r in respuesta.get_registros():
                    f.write(f"{r['id']}, {r['marca']}, {r['marca']}, {r['cantidad']}\n")
                    
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def get_registros(self):
        """
        Obtiene todos los registros del inventario.

        :return: Una lista de registros de inventario.
        :rtype: list
        """
        consulta = f"ACCION:GETREGISTROS<>TIPO:{self.tipo}<>USUARIO:{self.usuario}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def get_logs(self):
        """
        Obtiene todos los registros del log.

        :return: Una lista de registros del log.
        :rtype: list
        """
        consulta = f"ACCION:GETLOGS<>TIPO:{self.tipo}<>USUARIO:{self.usuario}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def consultar_logs(self, rol="", nombre="", accion="", fecha=""): 
        """
        Consulta los registros del log, permitiendo filtrar por rol, nombre, accion y/o fecha.
        Si el valor de rol es ingresado filtra por rol,
        Si el valor de nombre esta indicado, filtra por nombre
        Si el valor de accion esta indicado, filtra por accion.
        SI el valor de fecha esta especificado, filtra por la fecha especidicada.
        
        
        :param rol: (Opcional) El rol del registrado en el log a buscar.
        :type rol: str
        :param nombre: (Opcional) El nombre del registrado en el log a buscar.
        :type nombre: str
        :param accion: (Opcional) La acccion del registrado en el log a buscar.
        :type accion: str
        :param fecha: (Opcional) La fecha del registrado en el log a buscar.
        :type fecha: str
        :return: El resultado de la consulta, incluyendo los registros encontrados y el estado de la operación.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()
        
        regex_check = self.validador.valida_datos_logs(rol, nombre, accion, fecha)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        consulta = f"ACCION:CONSULTALOGS<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>ROL:{rol}<>NOMBRE:{nombre}<>ACCION_REALIZADA:{accion}<>FECHA:{fecha}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def exportar_logs(self, rol="", nombre="", accion="", fecha=""): 
        """
        Exporta los registros del log, permitiendo filtrar por rol, nombre, accion y/o fecha.
        Si el valor de rol es ingresado filtra por rol,
        Si el valor de nombre esta indicado, filtra por nombre
        Si el valor de accion esta indicado, filtra por accion.
        SI el valor de fecha esta especificado, filtra por la fecha especidicada.
        
        
        :param rol: (Opcional) El rol del registrado en el log a buscar.
        :type rol: str
        :param nombre: (Opcional) El nombre del registrado en el log a buscar.
        :type nombre: str
        :param accion: (Opcional) La acccion del registrado en el log a buscar.
        :type accion: str
        :param fecha: (Opcional) La fecha del registrado en el log a buscar.
        :type fecha: str
        :return: El resultado de la consulta, incluyendo los registros encontrados y el estado de la operación.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()
        
        regex_check = self.validador.valida_datos_logs(rol, nombre, accion, fecha)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        consulta = f"ACCION:EXPORTARLOGS<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>ROL:{rol}<>NOMBRE:{nombre}<>ACCION_REALIZADA:{accion}<>FECHA:{fecha}"
        respuesta = self.cliente.consulta(consulta)
        if respuesta.get_status() == 1:
                            
            if rol =="":
                rol = "ROL"
            if nombre == "":
                nombre = "NO"
            if accion == "":
                accion = "AC"
            if fecha == "":
                fecha = "FE"
            with open(f'logs_{rol}_{nombre}_{accion}_{fecha}.txt', 'w') as f:
                for r in respuesta.get_registros():
                    f.write(f"{r['rol']}, {r['nombre']}, {r['accion']}, {r['fecha']}, {r['hora']}, {r['id_registro']}, {r['marca_registro']}, {r['modelo_registro']}, {r['cantidad']}, {r['estado']}\n")
                    
        return respuesta

    @dev_log({"clase":"InventarioController"})
    def verificar_servidor(self):
        """Utiliza el controlador para revisar si el servidor esta activo

        Returns:
            bool tablas: True/False y las tablas o un error
        """
        conexion = self.cliente.get_conectado()
        try:
            if conexion:
                #Tomar las tablas de la base
                # Solicitar las tablas 
                consulta = f"ACCION:TABLAS<>TIPO:{self.tipo}<>USUARIO:{self.usuario}"
                respuesta = self.cliente.consulta(consulta)
        
                return True, respuesta.get_registros()
            else:
                return False, "No hay conexion con el servidor"
        except Exception as e:
            return False, str(e)
    
    @dev_log({"clase":"InventarioController"})
    def iniciar_servidor(self):
        """Revisa si el servidor esta activo, si no 
        Utiliza el controlador para iniciar si aun no esta iniciado.

        Returns:
            [bool error]: True/False y las tablas o un error
        """
        if not self.cliente.get_conectado():
            
            self.socket = Servidor()
            try:
                respuesta = self.socket.iniciar_servidor()
                if respuesta[0]:
                    self.socket_owner = True
                return respuesta
            except Exception as e:
                return [False, e]
        else:
            return [False, "Servidor ya esta iniciado"]
        
    @dev_log({"clase":"InventarioController"})
    def detener_servidor(self):
        """
        Detiene el servidor si el usuario es el propietario del socket.

        Este método intenta detener el servidor enviando una consulta al cliente.
        Si la consulta es exitosa, se llama al método `detener_servidor` del socket.

        Returns:
            list: Una lista con dos elementos:
                - bool: True si el servidor se detuvo correctamente, False en caso contrario.
                - str: Un mensaje que indica el resultado de la operación.
        """
        
        if self.socket_owner:
            try:
                consulta = f"ACCION:DETENER"
                respuesta = self.cliente.consulta(consulta)
                if respuesta.get_status():
                    respuesta = self.socket.detener_servidor()
                    return respuesta
                else:
                    [False, "Algo salio mal al apagar el servidor"]
            except Exception as e:
                return [False, str(e)]
        else:
            return [False, "No eres dueño del socket"]
        
    @dev_log({"clase":"InventarioController"})
    def set_usuario(self, usuario):
        """
        Establece el usuario actual.

        Args:
            usuario (str): El nombre del usuario.
        """
        self.usuario = usuario
        
    @dev_log({"clase":"InventarioController"})
    def set_tipo(self, tipo):
        """
        Establece el tipo de usuario actual.

        Args:
            tipo (str): El tipo de usuario (e.g., "admin", "usuario").
        """
        self.tipo = tipo
        
    @dev_log({"clase":"InventarioController"})
    def verifica_usuario(self, usuario, contrasena):
        """
        Verifica las credenciales de un usuario consultando al servidor.

        Args:
            usuario (str): El nombre de usuario a verificar.
            contrasena (str): La contraseña del usuario a verificar.

        Returns:
            Respuesta: Un objeto Respuesta del servidor que contiene:
                - status: 1 si la autenticación fue exitosa, 0 si no.
                - error: Un mensaje de error en caso de fallo (e.g., "Usuario no existe", "Contraseña incorrecta").
                - registros: Potencialmente, datos adicionales del usuario si la autenticación es exitosa.
        """
        respuesta = self.get_respuesta_vacia()
        if self.cliente.get_conectado():
            consulta = f"ACCION:LOGIN<>TIPO:Usuario<>USUARIO:{usuario}<>CONTRASENA:{contrasena}"
            respuesta = self.cliente.consulta(consulta)
            return respuesta
        else:
            respuesta.set_status(0)
            respuesta.set_error("No hay conexion con el servidor")
            return respuesta
        
    @dev_log({"clase":"InventarioController"})
    def enviar_mensaje(self, usuario=None, mensaje=""): 
        """
        Envia el mensaje al usuario.
        
        :param usuario: El usuario a quien le envia el mensaje 
        :type usuario: str
        :param mensaje:  El mensaje enviado.
        :type mensaje: str
        
        :return: El resultado de la consulta, incluyendo los registros encontrados y el estado de la operación.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.get_respuesta_vacia()
        if usuario:
            
            regex_check = self.validador.validar_mensaje(mensaje)
            if regex_check["status"] == False:
                respuesta.set_status(0)
                respuesta.set_error(regex_check["error"]) 
                return respuesta
            
            consulta = f"ACCION:ENVIAMENSAJE<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>DESTINATARIO:{usuario}<>MENSAJE:{mensaje}"
            respuesta = self.cliente.consulta(consulta)
        else:
            respuesta.set_status(0)
            respuesta.set_error("No usuario")
        return respuesta
    
    def enviar_mensaje_usuario(self,mensaje):
        return self.enviar_mensaje(self.usuario, mensaje)
    
    def get_mensajes(self, usuario = None):
        
        if usuario:
            consulta = f"ACCION:GETMENSAJES<>TIPO:{self.tipo}<>USUARIO:{self.usuario}<>DESTINATARIO:{usuario}"
            respuesta = self.cliente.consulta(consulta)
        else:
            respuesta.set_status(0)
            respuesta.set_error("No usuario")
        return respuesta
    
    def get_mensajes_usuario(self):
        return self.get_mensajes(self.usuario)
        
        
    def get_listado_usuarios(self):
        """metodo para obtener el listado de usuarios.
        """
        consulta = f"ACCION:GETUSUARIOS<>TIPO:{self.tipo}<>USUARIO:{self.usuario}"
        respuesta = self.cliente.consulta(consulta)
        return respuesta