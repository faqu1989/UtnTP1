import re
from decorador_dev_log import dev_log

class Validador:
    
    @dev_log({"clase":"Validador"})
    def valida_cadenas_registro(self,marca,modelo,cantidad):
        """Valida los datos de marca, modelo y cantidad usando expresiones regulares.

        Args:
            marca (str): La marca del producto.
            modelo (str): El modelo del producto.
            cantidad (str): La cantidad del producto.

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        respuesta = {"status": True, "error": ""}
        patron_alfanumerico = r"^\s*[A-Za-z0-9 _-]{3,}\s*$"  # Patrón para valores alfanuméricos con al menos 3 caracteres
        if not marca == "":
            if not re.match(patron_alfanumerico, marca):
                respuesta["status"] = False
                respuesta["error"] = "El valor de la marca no es válido"
                return respuesta
        if not modelo == "":
            if not re.match(patron_alfanumerico, modelo):
                respuesta["status"] = False
                respuesta["error"] = "El valor del modelo no es válido"
                return respuesta

        check_cantidad = self.valida_numero(cantidad)
        if check_cantidad["status"] == False:
            return check_cantidad

        return respuesta
    
    @dev_log({"clase":"Validador"})
    def valida_numero(self, numero):
        """Valida si un valor es numérico.

        Args:
            numero (str): El valor a validar.

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        patron_numerico = r"^\d+$"  # Patrón para valores numéricos
        respuesta = {"status": True, "error": ""}

        if not numero == "":
            if not re.match(patron_numerico, numero):
                respuesta["status"] = False
                respuesta["error"] = "El valor numérico no es válido, solo se aceptan números"

        return respuesta

    @dev_log({"clase":"Validador"})
    def valida_datos_logs(self,rol, nombre, accion, fecha):
        """Valida los datos de rol, nombre, accion y fecha usando expresiones regulares.

        Args:
            rol (str): El rol registrado en el log
            nombre (str): El nombre registrado en el log
            accion (str): La accion registrada en el log
            fecha (str): LA fecha registrada en el log

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        respuesta = {"status": True, "error": ""}
        patron_alfanumerico = r"^\s*[A-Za-z0-9 _-]{3,}\s*$"  # Patrón para valores alfanuméricos con al menos 3 caracteres
        patron_fecha = r"\d{2}-\d{2}-\d{4}"
        if not rol == "":
            if not re.match(patron_alfanumerico, rol):
                respuesta["status"] = False
                respuesta["error"] = "El valor del rol no es válido"
                return respuesta
        if not accion == "":
            if not re.match(patron_alfanumerico, accion):
                respuesta["status"] = False
                respuesta["error"] = "El valor de la accion no es válida"
                return respuesta
        if not nombre == "":
            if not re.match(patron_alfanumerico, nombre):
                respuesta["status"] = False
                respuesta["error"] = "El valor del nombre no es válido"
                return respuesta
        if not fecha == "":
            if not re.match(patron_fecha, fecha):
                respuesta["status"] = False
                respuesta["error"] = "El valor de la fecha no es válida"
                return respuesta

        return respuesta

    def validar_mensaje(self, mensaje):
        respuesta = {"status": True, "error": ""}
        patron = r"\S"  # \S coincide con cualquier carácter que NO sea un espacio en blanco
        if re.search(patron, mensaje):
            respuesta["status"] = True
            respuesta["error"] = ""
        else:
            respuesta["status"] = False
            respuesta["error"] = "El mensaje debe tener al menos un caracter."
        return respuesta