import functools
import logging

from datetime import datetime

# Configuración básica del logging (puedes personalizar esto)
logging.basicConfig(filename='acciones.log', level=logging.INFO,
                    format='%(asctime)s - %(message)s')

class ObservadorLog:
    """
    Clase observadora encargada de registrar acciones y sus parámetros en un log.

    Atributos:
        modelo: El modelo de datos al que se enviarán los registros (opcional).
    """

    def __init__(self, model=None):
        """
        Inicializa el observador.

        Args:
            model: El modelo de datos para guardar los registros (opcional).
        """
        self.modelo = model

    def actualizar(self, accion, args, kwargs, status):
        """
        Método llamado cuando se ejecuta una acción decorada.

        Args:
            accion: Nombre de la acción (nombre de la función decorada).
            args: Argumentos posicionales de la función.
            kwargs: Argumentos de palabra clave de la función.
            status: Estado de la acción (éxito o fracaso).
        """
        logging.info(f"Acción: {accion}, args: {args}, kwargs: {kwargs}")

        # Obtener fecha y hora actuales
        CURRENT_DATE = datetime.now().strftime("%d-%m-%Y")
        CURRENT_TIME = datetime.now().strftime("%H:%M:%S")
        estado = status
        # Inicializar variables para almacenar información del registro

        id_registro = None
        marca_registro = None
        modelo_registro = None
        cantidad = None
        
        # Extraer información relevante de los argumentos según la acción

        print(args)
        ACCION = args[1]
        TIPO_USUARIO = args[2]
        NOMBRE_USUARIO = args[3]
        if ACCION == "AGREGAR":
            id_registro = None
            marca_registro = args[4]
            modelo_registro = args[5]
            cantidad = args[6]
        elif ACCION == "LOGIN":
            pass
        elif ACCION == "TABLAS":
            pass
        elif ACCION == "MODIFICAR":
            id_registro = args[4]
            marca_registro = args[5]
            modelo_registro = args[6]
            cantidad = args[7]
        elif ACCION == "ELIMINAR":
            id_registro = args[4]
        elif ACCION == "CONSULTAR":
            id_registro = args[4]
            marca_registro = args[5]
            modelo_registro = args[6]
            cantidad = args[7]
        elif ACCION == "EXPORTAR":
            id_registro = args[4]
            marca_registro = args[5]
            modelo_registro = args[6]
            cantidad = args[7]
        elif ACCION == "GETREGISTROS":
            pass
        elif ACCION == "GETLOGS":
            pass
            
        elif ACCION == "CONSULTARLOGS":
            pass
        elif ACCION == "EXPORTARLOGS":
            pass
        # Guardar el log en la base de datos usando el modelo
        respuesta = self.modelo.guardar_log(TIPO_USUARIO, NOMBRE_USUARIO, ACCION,
                                            CURRENT_DATE, CURRENT_TIME,
                                            id_registro, marca_registro, modelo_registro,
                                            cantidad, estado)
        print("Log actualizado")
        #Hacer el input en el log
    def set_modelo(self,modelo):
        """
        Establece el modelo de datos para guardar los registros.

        Args:
            modelo: El modelo de datos a utilizar.
        """
        self.modelo = modelo

def registrar_accion(observador):
    """
    Decorador para registrar acciones y sus parámetros.

    Args:
        observador: El observador que recibirá las notificaciones.

    Returns:
        Un decorador que envuelve la función original.
    """
    def decorador(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Ejecutar la función original y obtener el resultado
            resultado = func(*args, **kwargs)
            # Notificar al observador con la acción, parámetros y estado
            observador.actualizar(func.__name__,args, kwargs,resultado.get_status())
            return resultado
        return wrapper
    return decorador

