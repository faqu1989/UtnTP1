import random 
from peewee import *
from respuesta import Respuesta
import re
from decorador_dev_log import dev_log
from validador import Validador
import datetime
from observador import ObservadorLog, registrar_accion

# Aplicación principal
observador = ObservadorLog()

    
# Modelo de Inventario
class InventarioModel:
    """
    Modelo para gestionar el inventario en una base de datos SQLite.

    Utiliza Peewee como ORM para interactuar con una base de datos SQLite.
    Este modelo proporciona métodos para agregar, modificar, eliminar y consultar registros de inventario.

    """  
    class Registro(Model):
        """
        Representa un registro individual en el inventario. Es necesario para la implementacion del ORM de peewee

        Atributos:
            id (AutoField): Identificador único del registro.
            marca (CharField): Marca del producto.
            modelo (CharField): Modelo del producto.
            cantidad (IntegerField): Cantidad disponible en el inventario.
        """
        
        id = AutoField(primary_key=True)
        marca = CharField()
        modelo = CharField()
        cantidad = IntegerField()
         
        def to_dict(self):
            return {
                "id": self.id,
                "marca": self.marca,
                "modelo": self.modelo,
                "cantidad": str(self.cantidad)
            }
            
        class Meta:
            database = SqliteDatabase('inventariado.db')
            
    class Usuario(Model):
        """
        Representa un usuario individual de la app.
        Es necesario para la implementacion del ORM de peewee

        Atributos:
            id (AutoField): Identificador único del registro.
            nombre (CharField): Marca del producto.
            contrasena (CharField): Modelo del producto.
        """
        
        id = AutoField(primary_key=True)
        nombre = CharField()
        contrasena = CharField()

        def to_dict(self):
            return {
                "nombre": self.nombre
            }
            
        class Meta:
            database = SqliteDatabase('inventariado.db')
    class Log(Model):
        """
        Representa un el log individual de cada usuario/adin/accion realizada
        Es necesario para la implementacion del ORM de peewee

        Atributos:
            id (AutoField): Identificador único del registro.
            rol (CharField): Usuario o admin.
            nombre (CharField): nombre del usuario o admin
            accion (CharField): accion realizada
            fecha (DateField): fecha
            hora (TimeField): hora
            id_registro (IntegerField): id del registro
            marca_registro (CharField): marca del registro
            modelo_registro (CharField): modelo del registor
            cantidad (IntegerField): cantidad del registro
            estado (BooleanField): Se realizo con exito o no la accion.
        """
        id = AutoField(primary_key=True)
        rol = CharField(choices=('usuario', 'administrador'))
        nombre = CharField()
        accion = CharField()
        fecha = DateField(default=datetime.date.today)
        hora = TimeField(default=datetime.datetime.now().time())
        id_registro = IntegerField(null=True)
        marca_registro = CharField(null=True)
        modelo_registro = CharField(null=True)
        cantidad = IntegerField(null=True)
        estado = BooleanField(default=True)
        
        def to_dict(self):
            return {
                "rol": self.rol,
                "nombre": self.nombre,
                "accion": self.accion,
                "fecha": self.fecha,
                "hora": self.hora.strftime("%H:%M:%S"),
                "id_registro": self.id_registro,
                "marca_registro": self.marca_registro,
                "modelo_registro": self.modelo_registro,
                "cantidad": self.cantidad,
                "estado": self.estado
            }
          
        class Meta:
            database = SqliteDatabase('inventariado.db')
            
              
    class Chat(Model):
        id = AutoField(primary_key=True)
        usuario = IntegerField()
        fecha_hora = DateTimeField(default=datetime.datetime.now)
        class Meta:
            database = SqliteDatabase('inventariado.db')
    class Mensaje(Model):
        chat = IntegerField()
        remitente = CharField()
        contenido = TextField()
        fecha_hora = DateTimeField(default=datetime.datetime.now)
        
        def to_dict(self):
            return {
                "remitente": self.remitente,
                "contenido": self.contenido,
                "fecha_hora": self.fecha_hora.strftime("%Y-%m-%d %H:%M:%S")
            }
        
        class Meta:
            database = SqliteDatabase('inventariado.db')
    
    def __init__(self):
        """
        Inicializa el modelo de inventario.

        Conecta a la base de datos y crea la tabla si no existe.
        """
        self.validador = Validador()
        self.db = SqliteDatabase('inventariado.db')
        self.crear_tabla()
        observador.set_modelo(self)

    
    def set_socket(self,socket):
        self.socket = socket
        
    
    def crear_tabla(self):
        """
        Crea la tabla 'Registro' en la base de datos si no existe.
        """
        try:
            self.db.connect()
            self.db.create_tables([self.Registro, self.Usuario, self.Log, self.Chat, self.Mensaje])
            self.create_dummies()  # Para datos de prueba
        except Exception as e:
            print(e)
 
     
    def create_dummies(self):
        """Crea registros de prueba (dummies) en la base de datos.

        Si hay menos de 10 registros existentes, se generan 15 registros aleatorios con marcas y modelos predefinidos.
        Adicionalmente se crean 3 usuarios.
        """
        registros = self.Registro.select()
        if len(registros) > 10:
            pass  # No se crean dummies si ya hay suficientes registros
        else:
            marcas = ["Apple", "Samsung", "Toyota", "Coca-Cola", "Nike", "Google", "Mercedes-Benz", "McDonald's", "Disney", "Adidas", "BMW", "Microsoft", "Intel", "Sony", "Louis Vuitton", "Honda", "Pepsi", "Zara", "Nescafé", "Nintendo"]
            modelos = ["iPhone 14", "Galaxy S23", "Corolla", "Mustang", "Air Force 1", "Pixel 7", "Clase C", "Big Mac", "Model 3", "Stan Smith", "Serie 3", "Surface Laptop", "Core i9", "PlayStation 5", "Neverfull", "Civic", "Aquafina", "AirPods Max", "Nespresso Vertuo", "Switch"]

            for i in range(15):
                registro_dummie = self.Registro(marca=random.choice(marcas), modelo=random.choice(modelos), cantidad=i)
                registro_dummie.save()
            for i in range(3):
                usuario_dummie = self.Usuario(nombre=f"usuario{i}", contrasena=f"usuario{i}")
                usuario_dummie.save()

            print("Dummies creados")
   
       
    def get_respuesta_vacia(self):
        """
        Obtiene una instancia vacía de la clase Respuesta.

        Returns:
            Respuesta: Una instancia de Respuesta con valores por defecto.
        """
        return Respuesta(status = 0, error = "", registros = [])
    
    @registrar_accion(observador)
    def agregar_registro(self,ac, tipo, usuario, marca, modelo, cantidad):
        """
        Agrega un nuevo registro al inventario.

        Args:
            marca (str): Marca del producto.
            modelo (str): Modelo del producto.
            cantidad (int): Cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el nuevo registro.
        """

        respuesta = self.get_respuesta_vacia()

        # Validación de datos con expresiones regulares
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
               
        try:
            nuevo_registro =  self.Registro(marca = marca, modelo = modelo , cantidad = cantidad)
            nuevo_registro.save()
            respuesta.set_status(1)
            respuesta.append_registro(nuevo_registro.to_dict())
        except Exception as e:
            respuesta.set_status(0)
            respuesta.append_registro(nuevo_registro.to_dict()) # Incluir el registro fallido en la respuesta en caso de que se desee utilizar
            respuesta.set_error(e)
        finally:
            return respuesta
    
    @registrar_accion(observador)
    def modificar_registro(self,ac,tipo, usuario,id,marca,modelo,cantidad):
        """
        Modifica un registro existente en el inventario.

        Args:
            id (int): ID del registro a modificar.
            marca (str): Nueva marca del producto.
            modelo (str): Nuevo modelo del producto.
            cantidad (int): Nueva cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el registro modificado.
        """
        respuesta = self.get_respuesta_vacia()
        
        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        try:
            registro = self.Registro.get_or_none(id = id)
            if registro:
                #El registro existe
                registro.marca = marca
                registro.modelo = modelo
                registro.cantidad = cantidad
                registro.save()
                respuesta.set_status(1)
                respuesta.append_registro(registro.to_dict())
            else:
                #el registro no exsite
                respuesta.set_status(0)
                respuesta.set_error("Registro no existe")
        except Exception as e:
            respuesta.set_status(0)
            respuesta.append_registro(registro.to_dict())# Incluir el registro fallido en la respuesta
            respuesta.set_error(e)
        finally:
            return respuesta
    
    @registrar_accion(observador)
    def eliminar_registro(self,ac,tipo, usuario,id):
        """
        Elimina un registro existente en el inventario.

        Args:
            id (int): ID del registro a modificar.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación
        """
        respuesta = self.get_respuesta_vacia()
        
        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        try:
            registro = self.Registro.get_or_none(id = id)
            if registro:
                registro.delete_instance()
                respuesta.set_status(1)
            else:
                respuesta.set_status(0)
                respuesta.set_error("Registro no existe")
        except Exception as e:
            respuesta.set_status(0)
            respuesta.set_error(e)
        finally:
            return respuesta
    
    @registrar_accion(observador)
    def consultar_registros(self,ac,tipo, usuario,id,marca,modelo,cantidad):
        """
        Realiza una consulta en el inventario, de acuerdo a los parametros de entrada.

        Args:
            id (int): ID del registro a modificar.
            marca (str): Nueva marca del producto.
            modelo (str): Nuevo modelo del producto.
            cantidad (int): Nueva cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el listado de los registros .
        """
        respuesta = self.get_respuesta_vacia()

        # Validación de ID y datos con expresiones regulares
        regex_check = self.checkRegexNumber(id)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        regex_check = self.checkRegex(marca,modelo,cantidad)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        # REvisar que valores son vacios para hacerlos None 
        # Aquellos que sean None no seran utilizados para formar el query de consulta.
        if id =="":
            id = None
        if marca == "":
            marca = None
        if modelo == "":
            modelo = None
        if cantidad == "":
            cantidad = None
        
        query  = self.Registro.select() #Comienza con una consulta basica
        
        # Agregar condiciones si los valores no son nulos
        if id is not None:
            query = query.where(self.Registro.id == id)
            
        if marca is not None:
            query = query.where(self.Registro.marca == marca)
            
        if modelo is not None:
            query = query.where(self.Registro.modelo == modelo)
            
        if cantidad is not None:
            query = query.where(self.Registro.cantidad <= cantidad)
        registros = list(query)
        
        if len(registros) > 0:
            respuesta.set_status(1)
            for registro in registros:
                respuesta.append_registro(registro.to_dict())
        else:
            respuesta.set_error("No Se encontraron registros")
            
        return respuesta

    @registrar_accion(observador)
    def exportar_registros(self,ac,tipo, usuario,id,marca,modelo,cantidad):
        """
        Realiza una consulta en el inventario para exportarlos, de acuerdo a los parametros de entrada.

        Args:
            id (int): ID del registro a modificar.
            marca (str): Nueva marca del producto.
            modelo (str): Nuevo modelo del producto.
            cantidad (int): Nueva cantidad disponible del producto.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el listado de los registros .
        """
        return self.consultar_registros(ac,tipo, usuario,id,marca,modelo,cantidad)
    
    @registrar_accion(observador)
    def get_registros(self,ac,tipo, usuario):
        """Obtiene todos los registros de la base de datos.

        Returns:
            peewee.ModelSelect: Un objeto que representa la consulta para obtener los registros.
        """
        respuesta = self.get_respuesta_vacia()
        registros = self.Registro.select().dicts()
        print(registros)
        if registros:
            for registro in registros:
                respuesta.append_registro(registro)
            respuesta.set_status(1)
        else:
            respuesta.set_status(0)
            respuesta.set_error("No Se encontraron registros")
        return respuesta

    def checkRegex(self, marca, modelo, cantidad):
        """Valida los datos de marca, modelo y cantidad 
        Utiliza la clase Validador para realizar la validacion
        usando expresiones regulares.

        Args:
            marca (str): La marca del producto.
            modelo (str): El modelo del producto.
            cantidad (str): La cantidad del producto.

        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        return self.validador.valida_cadenas_registro(marca,modelo,cantidad)

    def checkRegexNumber(self, number):
        """Valida si un valor es numérico.
        Utiliza la clase Validador para realizar la validacion

        Args:
            number (str): El valor a validar.
        Returns:
            dict: Un diccionario con el estado de la validación ("status": True/False) y un mensaje de error ("error").
        """
        return self.validador.valida_numero(number)
    
    @registrar_accion(observador)
    def consultar_logs(self,ac,tipo, usuario, rol, nombre, accion, fecha):
        """
        Realiza una consulta en el registro de logs, de acuerdo a los parametros de entrada.

        Args:
            rol (str): rol del log a. buscar del registro a modificar.
            nombre (str): nombre a busgar en el log.
            accion (str): accion a buscar en el log.
            fecha (str): fecha a buscar en el log.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el listado de los logs .
        """
        respuesta = self.get_respuesta_vacia()
        
        regex_check = self.validador.valida_datos_logs(rol, nombre, accion, fecha)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
        
        # REvisar que valores son vacios para hacerlos None 
        # Aquellos que sean None no seran utilizados para formar el query de consulta.
        if rol =="":
            rol = None
        if nombre == "":
            nombre = None
        if accion == "":
            accion = None
        if fecha == "":
            fecha = None
        
        query  = self.Log.select() #Comienza con una consulta basica
        
        # Agregar condiciones si los valores no son nulos
        if rol is not None:
            query = query.where(self.Log.rol == rol)
            
        if nombre is not None:
            query = query.where(self.Log.nombre == nombre)
            
        if accion is not None:
            query = query.where(self.Log.accion == accion)
            
        if fecha is not None:
            print(fecha)
            fecha_obj = datetime.datetime.strptime(fecha, "%d-%m-%Y").date().strftime("%d-%m-%Y")  # Convertir a objeto date
            query = query.where(self.Log.fecha == fecha_obj)
            print(fecha_obj)
        registros = list(query)
        
        if len(registros) > 0:
            print(registros)
            respuesta.set_status(1)
            for registro in registros:
                respuesta.append_registro(registro.to_dict())
        else:
            respuesta.set_error("No Se encontraron log registrados")
            
        return respuesta

    @registrar_accion(observador)
    def exportar_logs(self,ac,tipo, usuario, rol, nombre, accion, fecha):
        """
        Realiza una consulta en el registro de logs, de acuerdo a los parametros de entrada.

        Args:
            rol (str): rol del log a. buscar del registro a modificar.
            nombre (str): nombre a busgar en el log.
            accion (str): accion a buscar en el log.
            fecha (str): fecha a buscar en el log.

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso, el listado de los logs .
        """
        
        return self.consultar_logs(ac, tipo, usuario, rol, nombre, accion, fecha)

    @registrar_accion(observador)
    def get_logs(self,ac,tipo, usuario):
        """Obtiene todos los registros de la base de datos.

        Returns:
            peewee.ModelSelect: Un objeto que representa la consulta para obtener los registros.
        """
        respuesta = self.get_respuesta_vacia()
        registros = self.Log.select()
        
        if registros:
            respuesta.set_status(1)
            for registro in registros:                
                respuesta.append_registro(registro.to_dict())
        else:
            respuesta.set_status(0)
            respuesta.set_error("No se encontraron logs")
        return respuesta
    
    @registrar_accion(observador)
    def get_tablas(self,ac,tipo, usuario):
        """
        Obtiene una lista de los nombres de las tablas en la base de datos.

        Args:
            ac: No se utiliza en este método.
            tipo: No se utiliza en este método.
            usuario: No se utiliza en este método.

        Returns:
            Respuesta: Un objeto Respuesta que contiene:
                - status: 1 si la operación fue exitosa, 0 si hubo un error.
                - registros: Una lista con los nombres de las tablas si la operación fue exitosa, 
                            None si hubo un error.
                - error: Un mensaje de error si la operación falló, None si fue exitosa.
        """
        respuesta = self.get_respuesta_vacia()
        tablas = []
        try:
            cursor = self.db.execute_sql("SELECT name FROM sqlite_master WHERE type='table';")
            for row in cursor.fetchall():
                table_name = row[0]
                tablas.append(table_name)
            respuesta.set_status(1)
            respuesta.set_registros(tablas)
        except Exception as e:
            respuesta.set_error(e)
            respuesta.set_status(0)
        return respuesta
    
    @registrar_accion(observador)
    def verifica_usuario(self,ac,tipo, usuario, contrasena):
        """
        Verifica si un usuario existe en la base de datos.

        Args:
            ac: No se utiliza en este método.
            tipo: No se utiliza en este método.
            usuario: El nombre de usuario a verificar.
            contrasena: La contraseña del usuario a verificar.

        Returns:
            Respuesta: Un objeto Respuesta que contiene:
                - status: 1 si el usuario existe y la contraseña es correcta, 0 si no.
                - registros: Un diccionario con los datos del usuario si existe, None si no.
                - error: Un mensaje de error si el usuario no existe o la contraseña es incorrecta, 
                        None si la verificación fue exitosa.
        """
        respuesta = self.get_respuesta_vacia()

        # Verificar en la base de datos si es usuario normal
        user = self.Usuario.get_or_none(nombre = usuario, contrasena=contrasena)
        if user:
            #El usuario existe
            respuesta.set_status(1)
            respuesta.append_registro(user.to_dict())
        else:
            #el usuario no exsite
            respuesta.set_status(0)
            respuesta.set_error("Usuario no existe")
            
        return respuesta
    
    
    def guardar_log(self,rol,nombre, accion, fecha, hora, 
                    id_registro, marca_registro, modelo_registro,
                    cantidad, estado):
        """
        Guarda un registro de log en la base de datos.

        Args:
            rol: El rol del usuario que realizó la acción.
            nombre: El nombre del usuario que realizó la acción.
            accion: La acción realizada.
            fecha: La fecha en que se realizó la acción.
            hora: La hora en que se realizó la acción.
            id_registro: El ID del registro afectado por la acción (opcional).
            marca_registro: La marca del registro afectado por la acción (opcional).
            modelo_registro: El modelo del registro afectado por la acción (opcional).
            cantidad: La cantidad asociada a la acción (opcional).
            estado: El estado de la acción (True para éxito, False para fracaso).

        Returns:
            Respuesta: Un objeto Respuesta que contiene:
                - status: 1 si el log se guardó correctamente, 0 si hubo un error.
                - registros: Una lista con el nuevo registro guardado si fue exitoso, None si hubo un error.
                - error: Un mensaje de error si hubo un problema al guardar, None si fue exitoso.
        """
        respuesta = self.get_respuesta_vacia()
        
        try:
            nuevo_log =  self.Log(rol = rol, nombre = nombre , accion = accion,
                                  fecha = fecha, hora = hora, id_registro = id_registro, 
                                  marca_registro = marca_registro, modelo_registro= modelo_registro, 
                                  cantidad = cantidad, estado= estado)
            nuevo_log.save()
            respuesta.set_status(1)
            respuesta.append_registro(nuevo_registro)
        except Exception as e:
            respuesta.set_status(0)
            respuesta.append_registro(nuevo_registro) # Incluir el registro fallido en la respuesta en caso de que se desee utilizar
            respuesta.set_error(e)
        finally:
            return respuesta
        
    def enviar_mensaje(self,ac, tipo, usuario, destinatario, mensaje):
        """
        Envia un mensaje al usuario

        Args:
            accion (str): Marca del producto.
            tipo (str): Modelo del producto.
            usuario (int): Cantidad disponible del producto.
            destinatario
            mensaje

        Returns:
            Respuesta: Objeto Respuesta con el estado de la operación y, si es exitoso
        """

        respuesta = self.get_respuesta_vacia()

        # Validación de datos con expresiones regulares
        regex_check = self.validador.validar_mensaje(mensaje)
        if regex_check["status"] == False:
            respuesta.set_status(0)
            respuesta.set_error(regex_check["error"]) 
            return respuesta
               
        try:
            # Verificar en la base de datos si es usuario normal
            user = self.Usuario.get_or_none(nombre = destinatario)
            if user:
                #El usuario existe
                usuario_id = user.id
                chat = self.Chat.get_or_none(usuario = usuario_id)
                if chat:
                    # El chat ya existe
                    pass
                else:
                    # el chat no exite 
                    # hay que crearlo
                    chat = self.Chat(usuario= usuario_id)
                    chat.save()
                    chat = self.Chat.get_or_none(usuario = usuario_id)
                    print(chat)

                # Crear una nueva instancia de Mensaje
                nuevo_mensaje = self.Mensaje(
                    chat=chat.id,  # Asegúrate de pasar el objeto Chat, no solo el ID
                    remitente=usuario,  # Asegúrate de pasar el objeto Usuario, no solo el ID
                    contenido=mensaje
                )

                # Guardar el mensaje en la base de datos
                nuevo_mensaje.save()

                print("Mensaje almacenado exitosamente.")
                respuesta.set_status(1)
                respuesta.append_registro(nuevo_mensaje.to_dict())
            
            else:
                #usuriio no existe
                print(f"Error al almacenar el mensaje")
                respuesta.set_status(0)
                respuesta.set_error("El usuario no existe")
            
        except Exception as e:
            print(f"Error al almacenar el mensaje: {e}")
            respuesta.set_status(0)
            respuesta.set_error(e)
        finally:
            return respuesta
        
    def obtener_mensajes_chat(self,ac, tipo, usuario, destinatario):
        """Metodo para obtener los mensajes de un usuario

        Args:
            usuario (str): es el nombre del usuario
        """
        respuesta = self.get_respuesta_vacia()
        
        try:
            # Verificar en la base de datos si es usuario normal
            user = self.Usuario.get_or_none(nombre = destinatario)
            if user:
                
                #El usuario existe
                usuario_id = user.id
                chat = self.Chat.get_or_none(usuario = usuario_id)
                if chat:
                    # El chat ya existe
                    pass
                else:
                    # el chat no exite 
                    # hay que crearlo
                    chat = self.Chat(usuario= usuario_id)
                    chat.save()
                    chat = self.Chat.get_or_none(usuario = usuario_id)
                    print(chat)

                
                # Ya tenemos el chat, ahora a tomar los mensajes de este chat
                # Realizar la consulta para obtener los mensajes del chat, ordenados por fecha y hora
                mensajes = self.Mensaje.select().where(self.Mensaje.chat == chat.id).order_by(self.Mensaje.fecha_hora)

                # Puedes iterar sobre los mensajes y hacer lo que necesites con ellos
                if mensajes:
                    for mensaje in mensajes:
                        respuesta.append_registro(mensaje.to_dict())
                    respuesta.set_status(1)
                else:
                    respuesta.set_status(1)
                    respuesta.set_error("No mensajes")
                
            else:
                #El usuario. no existe:
                #usuriio no existe
                print(f"Error al tomar los mensajes.")
                respuesta.set_status(0)
                respuesta.set_error("El usuario no existe")

            
        except Exception as e:
            respuesta.set_status(0)
            respuesta.set_error(f"Error al obtener los mensajes del chat: {e}")
            print(f"Error al obtener los mensajes del chat: {e}")
         
        
        return respuesta
    
    def get_usuarios(self,ac,tipo, usuario):
        """Obtiene todos los usuarios de la base de datos

        Returns:
            peewee.ModelSelect: Un objeto que representa la consulta para obtener los registros.
        """
        respuesta = self.get_respuesta_vacia()
        registros = self.Usuario.select().dicts()
        print(registros)
        if registros:
            for registro in registros:
                respuesta.append_registro(registro)
            respuesta.set_status(1)
        else:
            respuesta.set_status(0)
            respuesta.set_error("No Se encontraron registros")
        return respuesta
    
    