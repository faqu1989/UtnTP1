import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk

from tkinter.ttk import  Label, Entry, Button
from tkinter import StringVar, DoubleVar, IntVar
from tkinter import END
from tkinter.messagebox import showinfo, showwarning
from tkcalendar import DateEntry
from tkcalendar import Calendar

from decorador_dev_log import dev_log
from datetime import datetime

import threading


# Vista
class AdminView(ttk.Frame):
    """
    Vista  del sistema de inventario desde el punto de vista del admin. Maneja la interfaz gráfica y la interacción con el controlador.

    :param root: La ventana raíz de la aplicación.
    :type root: tk.Tk
    :param controller: El controlador que gestiona la lógica de negocio.
    :type controller: ControladorInventario 
    """
    
    @dev_log({"clase":"AdminView"})
    def __init__(self, root,controller):
        """
        Inicializa el  InventarioView.

        Args:
            root (tk.Tk): La ventana raiz de la aplicacionThe root window of the application.
            controller (InventarioController): El controlador responsable de la logica.
        """
        
        self.controller = controller
        
        self.root = root
        self.root.title("Sistema de Inventario | Admin")

        # Configurar filas y columnas para expandirse
        self.root.rowconfigure(0)  # Fila 0 (frame_pestanas) se expande
        self.root.rowconfigure(1, weight=1)  # Fila 1 (frame_treeviews) se expande
        self.root.columnconfigure(0, weight=1)  # Columna 0 (ambos frames) se expande


        # Frame superior para los botones/pestañas
        #self.frame_superior = tk.Frame(self.root)
        #self.frame_superior.pack(fill=tk.X)  # Expandir horizontalmente

        # Notebook (pestañas)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.grid(row=0, column=0, sticky="new")

        # Frames para el contenido de cada pestaña
        self.frame_pestaña1 = tk.Frame(self.notebook)
        self.frame_pestaña2 = tk.Frame(self.notebook)
        self.frame_pestaña3 = tk.Frame(self.notebook)
        self.frame_pestaña4 = tk.Frame(self.notebook)
        

        self.notebook.add(self.frame_pestaña1, text="Inventario")
        self.notebook.add(self.frame_pestaña2, text="Registro de Log")
        self.notebook.add(self.frame_pestaña3, text="Chats")
        self.notebook.add(self.frame_pestaña4, text="Servidor")

        # Frame inferior para el contenido dinámico
        self.frame_inferior = tk.Frame(self.root)
        self.frame_inferior.rowconfigure(0, weight=1)  # Fila 1 (frame_treeviews) se expande
        self.frame_inferior.columnconfigure(0, weight=1)  # Columna 0 (ambos frames) se expande
        
        self.frame_inferior.grid(row=1, column=0, sticky="nsew")

        # Contenido inicial en el frame inferior (puedes cambiarlo según la pestaña seleccionada)
        tk.Label(self.frame_inferior, text="Contenido inicial").pack()

        # Función para cambiar el contenido del frame inferior
        def cambiar_contenido(event):
            pestaña_seleccionada = self.notebook.index(self.notebook.select())
            for widget in self.frame_inferior.winfo_children():
                widget.destroy()  # Borrar contenido anterior
            if pestaña_seleccionada == 0:
                self.show_inventario()

            elif pestaña_seleccionada == 1:
                self.show_log()
            elif pestaña_seleccionada == 2:
                self.show_chat()
            else:
                self.show_server()

        # Asociar la función al evento de cambio de pestaña
        self.notebook.bind("<<NotebookTabChanged>>", cambiar_contenido)
    
    @dev_log({"clase":"AdminView"})    
    def show_inventario(self):
        """
        Muestra la interfaz gráfica para la gestión del inventario.

        Crea y organiza los siguientes elementos en la ventana principal:

        - Frames:
            - frame1: Contiene etiquetas y campos de entrada para interactuar con el inventario.
            - frame2: Contiene botones para agregar, eliminar, modificar, consultar, exportar y limpiar registros.
            - frame3: Contiene un Treeview para mostrar los registros del inventario.

        - Etiquetas y Campos de Entrada:
            - id_label, id_entry: Etiqueta y campo para el ID del registro.
            - marca_label, marca_entry: Etiqueta y campo para la marca del producto.
            - modelo_label, modelo_entry: Etiqueta y campo para el modelo del producto.
            - cantidad_label, cantidad_entry: Etiqueta y campo para la cantidad del producto.

        - Botones:
            - agregar_button: Agrega un nuevo registro al inventario.
            - eliminar_button: Elimina un registro del inventario.
            - modificar_button: Modifica un registro existente.
            - consultar_button: Consulta y filtra registros.
            - exportar_button: Exporta los registros a un archivo.
            - limpiar_button: Limpia los campos de entrada.

        - Treeview:
            - Muestra los registros del inventario con columnas para ID, Marca, Modelo y Cantidad.
            - Se vincula a un evento `<<TreeviewSelect>>` para manejar la selección de elementos.
        """
        
        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.frame_inferior)
        #self.frame_inferior.pack(expand=True, fill=tk.BOTH)

        frame1.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.columnconfigure(1,weight=1)
        frame1.columnconfigure(2,weight=2)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)
        frame1.rowconfigure(2,weight=1)
        frame1.rowconfigure(3,weight=1)
        frame1.rowconfigure(4,weight=1)
        
        #Frame 2: va ubicado en el ultimo row de Frame1 y es para los botones
        frame2 = ttk.Frame(frame1)
        frame2.grid(row=4, column=0,columnspan=4,sticky="nsew", padx=5, pady=5)
        frame2.columnconfigure(0,weight=1)
        frame2.columnconfigure(1,weight=1)
        frame2.columnconfigure(2,weight=1)
        frame2.columnconfigure(3,weight=1)
        frame2.columnconfigure(4,weight=1)
        frame2.columnconfigure(5,weight=1)
        frame2.columnconfigure(6,weight=1)
        frame2.rowconfigure(0,weight=1)

        # Frame 3: es para el item list de elementos,
        frame3 = ttk.Frame(self.frame_inferior)
        frame3.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        frame3.columnconfigure(0,weight=1)
        frame3.rowconfigure(0,weight=1)

        # --- Etiquetas y campos de entrada --
        # Etiqueta y campo para el id
        id_label = ttk.Label(frame1, text="ID:")
        id_label.grid(row=0, column=0, padx=5, pady=10)
        self.id_entry = ttk.Entry(frame1)
        self.id_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Etiqueta y campo para el Marca
        marca_label = ttk.Label(frame1, text="Marca:")
        marca_label.grid(row=1, column=0, padx=5, pady=5)
        self.marca_entry = ttk.Entry(frame1)
        self.marca_entry.grid(row=1, column=1, padx=5, pady=5)

        # Etiqueta y campo para el Modelo
        modelo_label = ttk.Label(frame1, text="Modelo:")
        modelo_label.grid(row=2, column=0, padx=5, pady=5)
        self.modelo_entry = ttk.Entry(frame1)
        self.modelo_entry.grid(row=2, column=1, padx=5, pady=5)

        # Etiqueta y campo para la cantidad
        cantidad_label = ttk.Label(frame1, text="Cantidad:")
        cantidad_label.grid(row=3, column=0, padx=5, pady=5)
        self.cantidad_entry = ttk.Entry(frame1)
        self.cantidad_entry.grid(row=3, column=1, padx=5, pady=5)

        # --- Botones ---
        # Boton Agregar
        agregar_button = ttk.Button(frame2, text="Agregar", command=lambda:[self.agregar_registro(self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        agregar_button.grid(row=0, column=0, padx=5, pady=5)

        # Boton Eliminar
        eliminar_button = ttk.Button(frame2, text="Eliminar", command=lambda:[self.eliminar_registro(self.id_entry.get())])
        eliminar_button.grid(row=0, column=1, padx=5, pady=5)

        # Boton Modificar
        modificar_button = ttk.Button(frame2, text="Modificar", command=lambda:[self.modificar_registro(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        modificar_button.grid(row=0, column=2, padx=5, pady=5)

        # Boton Consultar
        consultar_button = ttk.Button(frame2, text="Consultar", command=lambda:[self.consultar_registros(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        consultar_button.grid(row=0, column=3, padx=5, pady=5)
        
        # Boton Exportar
        exportar_button = ttk.Button(frame2, text="Exportar", command=lambda:[self.exportar_registros(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        exportar_button.grid(row=0, column=4, padx=5, pady=5)
        
        # Boton Limiar Campos
        limpiar_button = ttk.Button(frame2, text="Limpiar", command=lambda:[self.limpiar_campos()])
        limpiar_button.grid(row=0, column=5, padx=5, pady=5)

        # --- Treeview ---
        self.treeview = ttk.Treeview(frame3, columns=("ID", "Marca", "Modelo", "Cantidad"), show="headings")
        self.treeview.heading("ID", text="ID")
        self.treeview.heading("Marca", text="Marca")
        self.treeview.heading("Modelo", text="Modelo")
        self.treeview.heading("Cantidad", text="Cantidad")
        self.treeview.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # Vincular evento de selección en el treevew
        self.treeview.bind("<<TreeviewSelect>>", self.on_tree_select)
        
        # Actualizar el treeview
        self.actualizar_view(self.treeview)
   
    @dev_log({"clase":"AdminView"})    
    def show_log(self):
        """
        Muestra la interfaz gráfica para consultar y exportar registros del log.

        Similar a `show_inventario`, esta función crea y configura los elementos de la interfaz, 
        incluyendo etiquetas, campos de entrada (combobox), un botón de selección de fecha y un Treeview 
        para mostrar los registros del log.
        """

        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.frame_inferior)
        #self.frame_inferior.pack(expand=True, fill=tk.BOTH)

        frame1.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.columnconfigure(1,weight=1)
        frame1.columnconfigure(2,weight=2)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)
        frame1.rowconfigure(2,weight=1)
        frame1.rowconfigure(3,weight=1)
        frame1.rowconfigure(4,weight=1)
        
        #Frame 2: va ubicado en el ultimo row de Frame1 y es para los botones
        frame2 = ttk.Frame(frame1)
        frame2.grid(row=4, column=0,columnspan=4,sticky="nsew", padx=5, pady=5)
        frame2.columnconfigure(0,weight=1)
        frame2.columnconfigure(1,weight=1)
        frame2.columnconfigure(2,weight=1)
        frame2.rowconfigure(0,weight=1)

        # Frame 3: es para el item list de elementos,
        frame3 = ttk.Frame(self.frame_inferior)
        frame3.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        frame3.columnconfigure(0,weight=1)
        frame3.rowconfigure(0,weight=1)

        # --- Etiquetas y campos de entrada --
        # Etiqueta y campo para el tipo de usuario
        tipo_usuario_label = ttk.Label(frame1, text="Tipo de usuario:")
        tipo_usuario_label.grid(row=0, column=0, padx=5, pady=10)
        # Opciones
        opciones_tipo_usuario = ["Admin", "Usuario"]
        self.tipo_usuario_seleccionado = tk.StringVar(value="")
        # Combobox
        self.tipo_usuario_combobox = ttk.Combobox(frame1, textvariable=self.tipo_usuario_seleccionado, values = opciones_tipo_usuario)
        self.tipo_usuario_combobox.grid(row=0, column=1, padx=5, pady=5)
        
        #Evento al seleccionar un valor
        self.tipo_usuario_combobox.bind("<<ComboboxSelected>>", self.seleccionar_tipo_usuario)
        #self.tipo_usuario_entry = ttk.Entry(frame1)
        #self.tipo_usuario_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Etiqueta y campo para el nombre
        nombre_label = ttk.Label(frame1, text="Nombre:")
        nombre_label.grid(row=1, column=0, padx=5, pady=5)
        self.nombre_entry = ttk.Entry(frame1)
        self.nombre_entry.grid(row=1, column=1, padx=5, pady=5)

        # Etiqueta y campo para el Modelo
        accion_label = ttk.Label(frame1, text="Accion:")
        accion_label.grid(row=2, column=0, padx=5, pady=5)
        # Opciones
        opciones_acciones = ["AGREGAR", "MODIFICAR", "CONSULTAR", "EXPORTAR", "ELIMINAR", "LOGIN", "CONSULTALOGS", "EXPORTARLOGS", "TABLAS", "GETLOGS", "GETREGISTROS"]
        self.accion_seleccionada = tk.StringVar(value="")
        # Combobox
        self.accion_combobox = ttk.Combobox(frame1, textvariable=self.accion_seleccionada, values = opciones_acciones)
        self.accion_combobox.grid(row=2, column=1, padx=5, pady=5)
        
        #Evento al seleccionar un valor
        self.accion_combobox.bind("<<ComboboxSelected>>", self.seleccionar_accion)
        
        #self.accion_entry = ttk.Entry(frame1)
        #self.modelo_entry.grid(row=2, column=1, padx=5, pady=5)

        # Etiqueta y campo para la fecha
        fecha_label = ttk.Label(frame1, text="Fecha:")
        fecha_label.grid(row=3, column=0, padx=5, pady=5)
        self.entry_fecha = ttk.Entry(frame1)
        self.entry_fecha.grid(row=3, column=1, padx=5, pady=5)

        boton_calendario = ttk.Button(frame1, text="Seleccionar Fecha", command=lambda:[self.seleccionar_fecha()])
        boton_calendario.grid(row=3, column=2, padx=5, pady=5)

        # Calendario (inicialmente oculto)
        #self.cal = Calendar(frame1, selectmode='day', year=2024, month=8, day=2)

        #self.cantidad_entry = ttk.Entry(frame1)
        #self.cantidad_entry.grid(row=3, column=1, padx=5, pady=5)

        # --- Botones ---
    
        # Boton Consultar
        consultar_button = ttk.Button(frame2, text="Consultar Log", command=lambda:[self.consultar_logs(self.tipo_usuario_seleccionado.get(),self.nombre_entry.get(), self.accion_seleccionada.get(), self.entry_fecha.get())])
        consultar_button.grid(row=0, column=0, padx=5, pady=5)
        
        # Boton Exportar
        exportar_button = ttk.Button(frame2, text="Exportar Log", command=lambda:[self.exportar_log(self.tipo_usuario_seleccionado.get(),self.nombre_entry.get(), self.accion_seleccionada.get(), self.entry_fecha.get())])
        exportar_button.grid(row=0, column=1, padx=5, pady=5)
        
        # Boton Limpiar Campos
        limpiar_button = ttk.Button(frame2, text="Limpiar Campos", command=lambda:[self.limpiar_campos_log()])
        limpiar_button.grid(row=0, column=2, padx=5, pady=5)
        
        # --- Treeview ---
        self.log_treeview = ttk.Treeview(frame3, columns=( "Tipo Usuario", "Nombre", "Accion", "Fecha", "Hora", "ID_registro", "Marca", "Modelo", "Cantidad", "Estado"), show="headings")

        self.log_treeview.heading("Tipo Usuario", text="Tipo Usuario")
        self.log_treeview.heading("Nombre", text="Nombre")
        self.log_treeview.heading("Accion", text="Accion")
        self.log_treeview.heading("Fecha", text="Fecha")
        self.log_treeview.heading("Hora", text="Hora")
        
        self.log_treeview.heading("ID_registro", text="ID_Marca")
        self.log_treeview.heading("Marca", text="Marca")
        self.log_treeview.heading("Modelo", text="Modelo")
        self.log_treeview.heading("Cantidad", text="Cantidad")
        self.log_treeview.heading("Estado", text="Estado")
        
        self.log_treeview.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # Vincular evento de selección en el treevew
        self.log_treeview.bind("<<TreeviewSelect>>", self.on_tree_log_select)
        for col in self.log_treeview["columns"]:
            self.log_treeview.column(col, width=min(self.log_treeview.column(col, "width"), 100))  # Límite de 200 píxeles
    
        # Actualizar el treeview
        self.actualizar_log_view(self.log_treeview)
    
    @dev_log({"clase":"AdminView"})    
    def show_chat(self):
        """
        Muestra la interfaz gráfica para contestar chats a diferentes usuarios.
        
        """
        
        self.usuario_seleccionado = None
        def seleccionar_usuario(event):
            item = treeview_usuarios.selection()  # Obtener el elemento seleccionado
            if item:
                self.usuario_seleccionado = treeview_usuarios.item(item, "values")[0]  # Obtener el nombre del usuario
                actualizar_mensajes()  # Actualizar los mensajes inmediatamente al seleccionar un usuario


        def actualizar_lista_usuarios():
            def obtener_datos_usuarios():
                nuevos_usuarios = []
                respuesta = self.controller.get_listado_usuarios()
                if respuesta.get_status():
                    nuevos_usuarios = respuesta.get_registros()
                else:
                    print(f"Error: {respuesta.get_error}")
            
                return nuevos_usuarios
            nuevos_usuarios = obtener_datos_usuarios()
            actualizar_treeview_usuarios(nuevos_usuarios)

        def actualizar_treeview_usuarios(nuevos_usuarios):
            # Limpiar el Treeview de usuarios
            for item in treeview_usuarios.get_children():
                treeview_usuarios.delete(item)
                
            for usuario in nuevos_usuarios:
                treeview_usuarios.insert("", END, text = "",  values=(usuario['nombre']))
                
        def actualizar_mensajes():
 
            if self.usuario_seleccionado:  
                respuesta = self.controller.get_mensajes(self.usuario_seleccionado)
                
                if respuesta.get_status():
                    nuevos_mensajes = respuesta.get_registros()
                    
                    for item in treeview_mensajes.get_children():
                        treeview_mensajes.delete(item)

                    # Insertar los nuevos mensajes
                    for mensaje in nuevos_mensajes:
                        treeview_mensajes.insert("", END,text="",values=(mensaje['remitente'], mensaje['contenido'], mensaje['fecha_hora']))
                        
                        #tree.insert('', END, text="" ,values=(registro["rol"], registro["nombre"], registro["accion"],registro["fecha"], registro["hora"], registro["id_registro"], registro["marca_registro"], registro["modelo_registro"], registro["cantidad"], registro["estado"]))

                else:
                    print(f"Error: {respuesta.get_error}")
            else:
                print(f"Error: no usuario seleccionado")
        # Función para simular el envío de un mensaje (reemplaza con tu lógica real)
        def enviar_mensaje():
            """
            Envia mensaje al chat del usuario seleccionado

            """
            mensaje = entry_mensaje.get()
            respuesta = self.controller.enviar_mensaje(self.usuario_seleccionado, mensaje)
            if respuesta.get_status():
                actualizar_mensajes()
                entry_mensaje.delete(0, tk.END)
            else:
                print(f"Error: {respuesta.get_error()}") 
                 
        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.frame_inferior)
        #self.frame_inferior.pack(expand=True, fill=tk.BOTH)

        frame1.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)
        frame1.rowconfigure(2,weight=1)
        
        # Treeview para la lista de usuarios
        treeview_usuarios = ttk.Treeview(frame1, columns=("Usuario"), show="headings")
        treeview_usuarios.heading("Usuario", text="Usuario")
        treeview_usuarios.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)

        # Treeview para los mensajes
        treeview_mensajes = ttk.Treeview(frame1, columns=("Remitente", "Mensaje", "Fecha/Hora"), show="headings")
        treeview_mensajes.heading("Remitente", text="Remitente")
        treeview_mensajes.heading("Mensaje", text="Mensaje")
        treeview_mensajes.heading("Fecha/Hora", text="Fecha/Hora")
        treeview_mensajes.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)

        frame2 = ttk.Frame(frame1)
        frame2.grid(row=2, column=0, sticky="nsew", padx=0, pady=0)
        frame2.columnconfigure(0,weight=4)
        frame2.columnconfigure(1,weight=1)
        frame2.columnconfigure(2,weight=1)
        frame2.rowconfigure(0,weight=1)
        
        # Entry para escribir el mensaje
        entry_mensaje = tk.Entry(frame2)
        entry_mensaje.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)

        # Botón para actualizar mensajes
        boton_actualizar = tk.Button(frame2, text="Actualizar Mensajes", command=actualizar_mensajes)
        boton_actualizar.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)

        # Botón para enviar el mensaje
        boton_enviar = tk.Button(frame2, text="Enviar", command=enviar_mensaje)
        boton_enviar.grid(row=0, column=2, sticky="nsew", padx=0, pady=0)

        # Asociar el evento de selección al Treeview de usuarios
        treeview_usuarios.bind("<<TreeviewSelect>>", seleccionar_usuario)


        # Iniciar las actualizaciones automáticas al abrir la ventana
        frame1.after(0, actualizar_lista_usuarios)
        frame1.after(0, actualizar_mensajes)
    
    @dev_log({"clase":"AdminView"})    
    def show_server(self):
        """
        Muestra la interfaz gráfica para controlar el servidor.

        Crea y configura los siguientes elementos en la ventana principal:

        - Frames:
            - frame1: Contiene la etiqueta de información y los botones para iniciar y apagar el servidor.

        - Etiqueta:
            - etiqueta_info: Muestra información sobre el estado del servidor.

        - Botones:
            - boton_iniciar: Inicia el servidor.
            - boton_apagar: Detiene el servidor (inicialmente deshabilitado).

        Atributos:
            - servidor_activo (bool): Indica si el servidor está actualmente activo.
        """
        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.frame_inferior)
        #self.frame_inferior.pack(expand=True, fill=tk.BOTH)

        frame1.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.columnconfigure(1,weight=1)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)

        
        #Frame 2: va ubicado en el ultimo row de Frame1 y es para los botones
        self.etiqueta_info = tk.Label(frame1, text="")
        self.etiqueta_info.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        
        self.boton_iniciar = ttk.Button(frame1, text="Iniciar Servidor", command=self.iniciar_servidor)
        self.boton_iniciar.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)

        self.boton_apagar = ttk.Button(frame1, text="Apagar Servidor", command=self.apagar_servidor, state=tk.DISABLED)
        self.boton_apagar.grid(row=1, column=1, sticky="nnsewew", padx=0, pady=0)

        # Estado inicial
        self.servidor_activo = False
        self.iniciar_servidor()
     
    def seleccionar_tipo_usuario(self,event):
        """
        Maneja la selección de un tipo de usiario en el combobox de tipo de usuario.

        Actualiza el valor de `self.tipo_usuario_seleccionado` con el tipo de usuario seleccionada en el combobox.
        Si no se selecciona ninguna usuario.

        Args:
            event (tk.Event): El evento de selección del combobox.
        """
        self.tipo_usuario_seleccionado.set(self.tipo_usuario_combobox.get())
        if self.tipo_usuario_seleccionado == "":
            print("No se ha seleccionado ningún valor")
        else:
            print(f"Valor seleccionado: {self.tipo_usuario_seleccionado}")

    def seleccionar_accion(self, event):
        """
        Maneja la selección de una acción en el combobox de acciones.

        Actualiza el valor de `self.accion_seleccionada` con la acción seleccionada en el combobox.
        Si no se selecciona ninguna acción, imprime un mensaje informativo en la consola.

        Args:
            event (tk.Event): El evento de selección del combobox.
        """
        self.accion_seleccionada.set(self.accion_combobox.get())
        if self.accion_seleccionada == "":
            print("No se ha seleccionado ningún valor" )
        else:
            print(f"Valor seleccionado: {self.accion_seleccionada}")

    def seleccionar_fecha(self):
        """
        Maneja la selección de una fecha en el calendario.

        Obtiene la fecha seleccionada en el calendario y la muestra en el campo de entrada de fecha (`self.entry_fecha`).
        """
        #fecha = self.cal.get_date()
        
        def obtener_fecha():
            fecha = cal.get_date()
            fecha_formateada = datetime.strptime(fecha, "%m/%d/%y").strftime("%d-%m-%Y")  # Formatear fecha

            self.entry_fecha.delete(0, tk.END)
            self.entry_fecha.insert(0, fecha_formateada)
            ventana_calendario.destroy()

        ventana_calendario = tk.Toplevel(self.frame_inferior)
        cal = Calendar(ventana_calendario, selectmode="day", year=2024, month=8, day=4)
        cal.pack(pady=20)

        boton_obtener = ttk.Button(ventana_calendario, text="Obtener Fecha", command=obtener_fecha)
        boton_obtener.pack()

    @dev_log({"clase":"AdminView"})
    def on_tree_select(self, event):
        """
        Maneja la selección de un elemento en el Treeview del inventario.

        Rellena los campos de entrada (ID, Marca, Modelo, Cantidad) con los valores del elemento seleccionado en el Treeview.
        Utiliza un bloque `try-except` para manejar el caso en que la selección se deseleccione debido a actualizaciones en el Treeview.

        Args:
            event (tk.Event): El evento de selección en el Treeview.
        """
        #Cuando esta en 'bind' un evento es accionado por diferentes motivos, no solo cuando es seleccionado,
        #Tambien se activa cuando se deselecciona por actualizar, o agregar elementos, eso genera un error o warning, pues deja de encontrarlo
        #Para evitar este error se agrega un try
        try:
            
            item = self.treeview.selection()[0]
            values = self.treeview.item(item, "values")
            self.id_entry.delete(0, tk.END)
            self.id_entry.insert(0, values[0])
            self.marca_entry.delete(0, tk.END)
            self.marca_entry.insert(0, values[1])
            self.modelo_entry.delete(0, tk.END)
            self.modelo_entry.insert(0, values[2])
            self.cantidad_entry.delete(0, tk.END)
            self.cantidad_entry.insert(0, values[3])
        except Exception as e:
            print(f"Debido a cambios en las listas, la seleccion anterior se deselecciono de la lista")

    @dev_log({"clase":"AdminView"})
    def on_tree_log_select(self, event):
        """
        Maneja la selección de un elemento en el Treeview del log.

        Rellena los campos de entrada (Tipo de Usuario, Nombre, Acción, Fecha) con los valores del elemento seleccionado en el Treeview del log.
        Utiliza un bloque `try-except` para manejar el caso en que la selección se deseleccione debido a actualizaciones en el Treeview.

        Args:
            event (tk.Event): El evento de selección en el Treeview.
        """
        #Cuando esta en 'bind' un evento es accionado por diferentes motivos, no solo cuando es seleccionado,
        #Tambien se activa cuando se deselecciona por actualizar, o agregar elementos, eso genera un error o warning, pues deja de encontrarlo
        #Para evitar este error se agrega un try
        try:

            item = self.log_treeview.selection()[0]
            values = self.log_treeview.item(item, "values")
            self.tipo_usuario_seleccionado.set("")
            self.tipo_usuario_seleccionado.set(values[0])
            self.nombre_entry.delete(0, tk.END)
            self.nombre_entry.insert(0, values[1])
            self.accion_seleccionada.set("")
            self.accion_seleccionada.set(values[2])
            self.entry_fecha.delete(0, tk.END)
            self.entry_fecha.insert(0, values[3])
        except Exception as e:
            print(f"Debido a cambios en las listas, la seleccion anterior se deselecciono de la lista")

    @dev_log({"clase":"AdminView"})
    def agregar_registro(self, marca, modelo, cantidad):
        """
        Agrega un registro nuevo al inventario
        Add a new inventory record.

        Args:
            marca (str): La marca del nuevo item.
            modelo (str): El modelo del nuevo item.
            cantidad (int): La cantidad del nuevo item.
        """
        respuesta = self.controller.agregar_registro(marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "agregar")

    @dev_log({"clase":"AdminView"})
    def eliminar_registro(self, id):
        """
        Elimina un registro del inventario

        Args:
            id (int): El ID del registro a eliminar
        """
        respuesta = self.controller.eliminar_registro(id)
        self.handle_respuesta(respuesta, "eliminar")    
          
    @dev_log({"clase":"AdminView"}) 
    def modificar_registro(self, id, marca, modelo, cantidad):
        """
        Modifica un registro existente en el inventario.

        :param id: El ID del registro a modificar.
        :param marca: La nueva marca del producto.
        :param modelo: El nuevo modelo del producto.
        :param cantidad: La nueva cantidad en inventario.
        """
        respuesta = self.controller.modificar_registro(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "modificar")

    @dev_log({"clase":"AdminView"})
    def consultar_registros(self, id, marca, modelo, cantidad):
        """
        Consulta registros en el inventario según los criterios especificados.

        :param id: El ID del registro a buscar (opcional).
        :param marca: La marca del producto a buscar (opcional).
        :param modelo: El modelo del producto a buscar (opcional).
        :param cantidad: La cantidad mínima en inventario a buscar (opcional).
        """
        respuesta = self.controller.consultar_registros(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "consultar")

    @dev_log({"clase":"AdminView"})
    def exportar_registros(self, id, marca, modelo, cantidad):
        """
        Exporta los registros del inventario que cumplen los criterios especificados.

        :param id: El ID del registro a exportar (opcional).
        :param marca: La marca del producto a exportar (opcional).
        :param modelo: El modelo del producto a exportar (opcional).
        :param cantidad: La cantidad mínima en inventario a exportar (opcional).
        """
        respuesta = self.controller.exportar_registros(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "exportar")

    @dev_log({"clase":"AdminView"})
    def handle_respuesta(self,respuesta,tipo):
        """
        Maneja la respuesta de una operación (agregar, modificar, eliminar, consultar, exportar).

        :param respuesta: Objeto de respuesta con información sobre el resultado de la operación.
        :param tipo: El tipo de operación realizada.
        """
        print("Inside handle")
        error = respuesta.get_error()
        textoExito = ""
        textoFracaso= ""
        if tipo == 'agregar':
            textoExito = "El registro se ha agregado con exito"
            textoFracaso = f"Ups! Algo salio mal al agregar el registro: {error}"
        elif tipo == 'modificar':
            textoExito = "El registro se ha modificado con exito"
            textoFracaso = f"Ups! Algo salio mal al modificar el registro: {error}"
        elif tipo == 'eliminar':
            textoExito = "El registro se ha eliminado con exito"
            textoFracaso = f"Ups! Algo salio mal al eliminar el registro: {error}"
        elif tipo == 'consultar':
            textoExito = "La consulta se ha realizado con exito"
            textoFracaso = f"Ups! Algo salio mal al realizar la consulta: {error}"
        elif tipo == 'exportar':
            textoExito = "Se han exportado los datos con exito"
            textoFracaso = f"Ups! Algo salio mal al exportar la consulta: {error}"
        elif tipo == 'consultar_logs':
            textoExito = "La consulta se ha realizado con exito"
            textoFracaso = f"Ups! Algo salio mal al realizar la consulta: {error}"
        elif tipo == 'exportar_logs':
            textoExito = "Se han exportado los datos con exito"
            textoFracaso = f"Ups! Algo salio mal al exportar la consulta: {error}"
        else:
            textoExito = f"Algo anda mal, favor de contactar al desarrollador: {tipo} "
            textoFracaso = f"Ups! Algo salio mal al agregar el registro: {error}"
        print("Error calculated handle")
        
        if respuesta.get_status() == 1 :
            if tipo in ["consultar", "exportar"]:
                self.actualizar_view(self.treeview,respuesta.get_registros())
            elif tipo in ["consultar_logs", "exportar_logs"]:
                self.actualizar_log_view(self.log_treeview,respuesta.get_registros())
            else:
                self.actualizar_view(self.treeview)
                
            print("actualizando view")
            #showinfo("Informacion",textoExito)
        else:
            #showwarning("Advertencia!",textoFracaso)
            pass
    
    @dev_log({"clase":"AdminView"})
    def consultar_logs(self, rol, nombre, accion, fecha):
        """
        Consulta registros en el log según los criterios especificados.

        :param rol: El rol del usuario en el log.
        :param nombre: Nombre del usuario en el log.
        :param accion: La accion realizada.
        :param fecha:La fecha del registro dellog.
        """
        respuesta = self.controller.consultar_logs(rol, nombre, accion, fecha)
        self.handle_respuesta(respuesta, "consultar_logs")

    @dev_log({"clase":"AdminView"})
    def exportar_log(self, rol, nombre, accion, fecha):
        """
        Exporta registros en el log según los criterios especificados.

        :param rol: El rol del usuario en el log.
        :param nombre: Nombre del usuario en el log.
        :param accion: La accion realizada.
        :param fecha:La fecha del registro dellog.
        """
        respuesta = self.controller.exportar_logs(rol, nombre, accion, fecha)
        self.handle_respuesta(respuesta, "exportar_logs")

    @dev_log({"clase":"AdminView"})
    def limpiar_campos(self):
        """
        Limpia los campos de entrada de datos en la interfaz registros de admin.
        """
        try:
            self.id_entry.delete(0, tk.END)
            self.marca_entry.delete(0, tk.END)
            self.modelo_entry.delete(0, tk.END)
            self.cantidad_entry.delete(0, tk.END)
        except Exception as e:
            print(f"No se pudieron Limpiar los campos {e}")
    
    @dev_log({"clase":"AdminView"})
    def limpiar_campos_log(self):
        """
        Limpia los campos de entrada de datos en la interfaz log de usuario.
        """
        try:
            self.tipo_usuario_seleccionado.set("")
            self.nombre_entry.delete(0, tk.END)
            self.accion_seleccionada.set("")
            self.entry_fecha.delete(0, tk.END)
        except Exception as e:
            print(f"No se pudieron Limpiar los campos {e}")
      
      
    @dev_log({"clase":"AdminView"})
    def actualizar_view(self, tree, registros_nuevos = None):
        """
        Actualiza la vista del árbol (treeview) con los registros del inventario.

        :param tree: El widget Treeview a actualizar.
        :param registros_nuevos: Lista opcional de nuevos registros para mostrar. 
                                Si es None, se obtendrán los registros del controlador.
        """
        
        registros = tree.get_children()
        for registro in registros:
            tree.delete(registro)
        
        if registros_nuevos is None:
            respuesta = self.controller.get_registros()
            
            if respuesta.get_status() == 1:
                registros_nuevos = respuesta.get_registros()
            else: 
                showwarning("Error:",respuesta.get_error())
        if not registros_nuevos is None:
            for registro in registros_nuevos:
                tree.insert('', END, text="" ,values=(registro["id"], registro["marca"], registro["modelo"], registro["cantidad"]))
        
    @dev_log({"clase":"AdminView"})
    def actualizar_log_view(self, tree, log_nuevos = None):
        """
        Actualiza la vista del árbol (treeview) con los registros del log.

        :param tree: El widget Treeview a actualizar.
        :param registros_nuevos: Lista opcional de nuevos registros para mostrar. 
                                Si es None, se obtendrán los registros del controlador.
        """
        
        registros = tree.get_children()
        for registro in registros:
            tree.delete(registro)
        
        if log_nuevos is None:
            respuesta = self.controller.get_logs()

            if respuesta.get_status() == 1:
                log_nuevos = respuesta.get_registros()
            else:
                print(respuesta.get_error())
                showwarning("Error:",respuesta.get_error())
        
        if not log_nuevos is None:    
            for registro in log_nuevos:
                tree.insert('', END, text="" ,values=(registro["rol"], registro["nombre"], registro["accion"],registro["fecha"], registro["hora"], registro["id_registro"], registro["marca_registro"], registro["modelo_registro"], registro["cantidad"], registro["estado"]))
        
        """
        TODO
        UN notepad que hace loginview.
        Returns:
            _type_: _description_
            
        
        """
    @dev_log({"clase":"AdminView"})
    def verificar_servidor(self):
        """
        Verifica si el servidor está activo utilizando el controlador.

        Returns:
            tuple: Una tupla con dos elementos:
                - bool: True si el servidor está activo, False en caso contrario.
                - list or str: Una lista de tablas si el servidor está activo, o un mensaje de error si no lo está.
        """
        return self.controller.verificar_servidor()
    
    @dev_log({"clase":"AdminView"})
    def iniciar_servidor(self):
        """
        Inicia el servidor si no está activo.

        Verifica primero si el servidor ya está activo. Si no lo está, intenta iniciarlo utilizando el controlador.
        Si el inicio es exitoso, actualiza la interfaz gráfica para reflejar el estado activo del servidor y muestra
        información sobre las tablas disponibles. Si hay un error, muestra un mensaje de advertencia.

        Returns:
            None
        """
        try:
            
            self.servidor_activo, tablas = self.verificar_servidor()
            if self.servidor_activo:
                self.boton_iniciar.config(state=tk.DISABLED)
                self.boton_apagar.config(state=tk.NORMAL)
                self.mostrar_informacion(tablas)
            else:
                # Si noe sta activo ay que iniciarlo.
                inicio_servidor = self.controller.iniciar_servidor()
                if inicio_servidor[0]:
                    self.servidor_activo, tablas = self.verificar_servidor()
                    if self.servidor_activo:
                        self.boton_iniciar.config(state=tk.NORMAL)
                        self.boton_apagar.config(state=tk.NORMAL)
                        self.mostrar_informacion(tablas)
                        showinfo("Iniciado","Servidor iniciado")

                    else:
                        showwarning("Error", f"No se pudo iniciar el servidor")
                else:
                    showwarning("Error", f"No se pudo iniciar el servidor: {inicio_servidor[1]}")
        except Exception as e:
            print(e)
    @dev_log({"clase":"AdminView"})
    
    def apagar_servidor(self):
        """
        Apaga el servidor.

        Utiliza el controlador para detener el servidor. Luego, actualiza la interfaz gráfica para reflejar el estado
        inactivo del servidor y borra la información mostrada.
        """
        self.controller.detener_servidor()
        
        self.servidor_activo = False
        self.boton_iniciar.config(state=tk.NORMAL)
        self.boton_apagar.config(state=tk.DISABLED)
        self.etiqueta_info.config(text="")

    @dev_log({"clase":"AdminView"})
    def mostrar_informacion(self,tablas):
        """
        Muestra información sobre el servidor en la interfaz gráfica.

        Verifica si el servidor está activo y, si lo está, actualiza la interfaz gráfica para mostrar:
        - El estado del servidor.
        - El nombre de la base de datos.
        - La lista de tablas disponibles.
        - La dirección del servidor.

        Args:
            tablas (list): Lista de nombres de tablas en la base de datos.
        """
        if self.servidor_activo:
            self.boton_iniciar.config(state=tk.DISABLED)
            self.boton_apagar.config(state=tk.NORMAL)
            
            info_servidor = "Servidor activo:\n"
            info_servidor += f"Base de datos: tu_base_de_datos.db\n"  # Reemplaza con tu nombre de archivo
            info_servidor += "Tablas:\n"
            for tabla in tablas:
                info_servidor += f" - {tabla}\n"
            info_servidor += "Dirección: localhost\n"  # Ajusta si es diferente
            self.etiqueta_info.config(text=info_servidor)
            
            