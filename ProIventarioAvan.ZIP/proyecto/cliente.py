import socket
import json
from respuesta import Respuesta
from decorador_dev_log import dev_log

class Cliente:
    """
    Clase que representa un cliente para interactuar con un servidor a través de sockets.

    Atributos:
        puerto (int): El puerto al que se conectará el cliente.
        host (str): La dirección IP o nombre de host del servidor (inicialmente None).
        conectado (bool): Indica si el cliente está conectado al servidor.
        cliente_socket (socket.socket): El objeto socket utilizado para la conexión (inicialmente None).
        error (str): Almacena un mensaje de error si ocurre alguno durante la conexión.
    """
    
    @dev_log({"clase":"Cliente"})
    def __init__(self):
        """
        Inicializa un nuevo objeto Cliente.

        Establece los valores iniciales de los atributos del cliente.
        """
        self.puerto = 9999
        self.host = None
        self.conectado = False
        self.cliente_socket = None
        self.error = ""
        
    @dev_log({"clase":"Cliente"})     
    def get_respuesta_vacia(self):
        """
        Obtiene una instancia vacía de la clase Respuesta.

        Returns:
            Respuesta: Una instancia de Respuesta con valores por defecto.
        """
        return Respuesta()
    
    @dev_log({"clase":"Cliente"})
    def revisar_conexion(self):
        """
        Verifica la conexión con el servidor.

        Envía un mensaje "PING" al servidor para comprobar si está activo.
        Actualiza el estado de conexión (self.conectado) y el mensaje de error (self.error) en consecuencia.

        Returns:
            Respuesta: Un objeto Respuesta del servidor indicando el estado de la conexión.
        """
        respuesta = self.get_respuesta_vacia()
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect(('localhost', self.puerto))
                consulta = "ACCION:PING"
                s.sendall(consulta.encode())
                data = s.recv(1024).decode()
                response = data
                print(response)
                json_str = json.loads(data)
                respuesta =  respuesta.from_json(json_str)
                print(respuesta)
                if respuesta.get_status():
                    self.conectado = True
                    self.error = ""

        except Exception as e:
            print(e)
            self.host = None
            self.conectado = False
            self.cliente_socket = None
            self.error = str(e)
            respuesta.set_error(e)
        return respuesta

        
    @dev_log({"clase":"Cliente"})
    def consulta(self, consulta):
        """
        Envía una consulta al servidor y recibe una respuesta.

        Args:
            consulta (str): La consulta a enviar al servidor.

        Returns:
            Respuesta: Un objeto Respuesta del servidor con el resultado de la consulta.
        """ 
        respuesta = self.get_respuesta_vacia()
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.connect(('localhost', self.puerto))
                s.sendall(consulta.encode())
                data = s.recv(65536).decode()
                json_str = json.loads(data)
                print(f"Recibiendo: {json_str}")
                respuesta =  respuesta.from_json(json_str)
            except Exception as e:
                print(e)
                respuesta.set_status(0)
                respuesta.set_error(e)
                s.close()
            finally:
                s.close()
        return respuesta

    @dev_log({"clase":"Cliente"})
    def get_conectado(self):
        """
        Obtiene el estado de conexión actual del cliente.

        Verifica la conexión con el servidor antes de devolver el estado.

        Returns:
            bool: True si el cliente está conectado, False en caso contrario.
        """
        respuesta = self.revisar_conexion()
        return self.conectado