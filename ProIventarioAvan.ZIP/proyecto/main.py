import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk

from controlador import InventarioController  # Importa el controlador (lógica)
from login_view import LoginView
from cliente import Cliente

try:
      
   # Aplicación principal
   if __name__ == "__main__":
      """
      Punto de entrada principal de la aplicación de inventario.

      Esta sección se ejecuta cuando el script se llama directamente (no se importa como módulo).
      Aqui se abre el view para el login, aqui dentro se tiene la oportunidad de iniciar secion como usuario o como administrador.
      Los usuarios solo pueden iniciar sesion, se el servidor esta en funcionamiento.
      Solo los administradores pueden hechar a correr el servido
      """ 

      # Uso de ThemedTk para aplicar temas visuales
      root = ThemedTk(theme="arc")
      root.title("Login de Sistema de Inventario")  # Agrega un título a la ventana principal
      
      # Definición del modelo (datos)
      cliente = Cliente()
      """
      .. autoclass:: Cliente
         :members:
         :undoc-members:
         :show-inheritance:
      """
      
      # Definición del controlador (lógica)
      controller = InventarioController(cliente)
      """
      .. autoclass:: InventarioController
         :members:
         :undoc-members:
         :show-inheritance:
      """


      # Inicia el bucle principal de la interfaz gráfica (Tkinter)
      app = LoginView(root,controller)
      """
      .. autoclass:: LoginView
         :members:
         :undoc-members:
         :show-inheritance:
      """
      
      root.mainloop()
except Exception as e:
   print(e)