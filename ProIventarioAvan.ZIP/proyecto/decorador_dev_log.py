from datetime import datetime
import functools

def dev_log(parametros={"clase":""}):
    """
    Decorator para registrar logs de desarrollo de funciones.

    Este decorador registra información detallada sobre las funciones a las que se aplica,
    incluyendo su nombre, argumentos posicionales y argumentos de palabra clave. La información
    se imprime en la consola para fines de depuración y desarrollo.

    Args:
        parametros (dict, optional): Diccionario con parámetros opcionales para el log.
            - clase (str, optional): Nombre de la clase a la que pertenece la función. Por defecto es "".

    Returns:
        callable: El decorador que envuelve la función original.
    """
    def decorador(func):
        """
        Decorador interno que envuelve la función y registra la información del log.

        Args:
            func (callable): La función a decorar.

        Returns:
            callable: Un wrapper que llama a la función original y registra los logs.
        """
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            """
            Wrapper que ejecuta la función y registra los logs.

            Args:
                *args: Argumentos posicionales de la función.
                **kwargs: Argumentos de palabra clave de la función.

            Returns:
                El resultado de la función original.
            """
            #clase = parametros.get('clase', "")
            texto = f"Metodo: {func.__name__}"
            for arg in args:
                try:
                    texto = texto + f" _ {arg}"
                except: 
                    pass
            for nombre, valor in kwargs.items():
                try:
                    texto = texto + f" _ {nombre} : {valor}"
                except:
                    pass
            print(texto)
            with open("dev_log.log","a+") as file:
                file.write(texto+"\n")
            return func(*args, **kwargs)
        return wrapper
    return decorador