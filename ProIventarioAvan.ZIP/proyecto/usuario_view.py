import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter.ttk import  Label, Entry, Button
from tkinter import StringVar, DoubleVar, IntVar
from tkinter import END
from tkinter.messagebox import showinfo, showwarning
from decorador_dev_log import dev_log
# Vista
class UsuarioView(ttk.Frame):
    """
    Vista principal del sistema de inventario. Maneja la interfaz gráfica y la interacción con el controlador.

    :param root: La ventana raíz de la aplicación.
    :type root: tk.Tk
    :param controller: El controlador que gestiona la lógica de negocio.
    :type controller: ControladorInventario 
    """
    @dev_log({"clase":"UsuarioView"})
    def __init__(self,root, controller):
        """
        Inicializa el  UsuarioView.

        Args:
            root (tk.Tk): La ventana raiz de la aplicacionThe root window of the application.
            controller (InventarioController): El controlador responsable de la logica.
        """
        
        self.controller = controller
        
        self.root = root
        self.root.title("Sistema de Inventario | Admin")

        # Frame superior para los botones/pestañas
        #self.frame_superior = tk.Frame(self.root)
        #self.frame_superior.pack(fill=tk.X)  # Expandir horizontalmente

        # Notebook (pestañas)
        self.notebook = ttk.Notebook(self.root)
        

        # Frames para el contenido de cada pestaña
        self.frame_pestaña1 = tk.Frame(self.notebook)
        self.frame_pestaña2 = tk.Frame(self.notebook)
        
        self.notebook.add(self.frame_pestaña1, text="Inventario")
        self.notebook.add(self.frame_pestaña2, text="Chat")

        self.frame_inferior = tk.Frame(self.root)

        # Configurar filas y columnas para expandirse
        self.root.rowconfigure(0)  # Fila 0 (frame_pestanas) se expande
        self.root.rowconfigure(1, weight=1)  # Fila 1 (frame_treeviews) se expande
        self.root.columnconfigure(0, weight=1)  # Columna 0 (ambos frames) se expande

        self.notebook.grid(row=0, column=0, sticky="new")
        
        # Frame inferior para el contenido dinámico
        self.frame_inferior.grid(row=1, column=0, sticky="nsew")
        self.frame_inferior.rowconfigure(0, weight=1)  # Fila 1 (frame_treeviews) se expande
        self.frame_inferior.columnconfigure(0, weight=1)  # Columna 0 (ambos frames) se expande
        # Contenido inicial en el frame inferior 

        # Función para cambiar el contenido del frame inferior
        def cambiar_contenido(event):
            pestaña_seleccionada = self.notebook.index(self.notebook.select())
            for widget in self.frame_inferior.winfo_children():
                widget.destroy()  # Borra contenido anterior
            if pestaña_seleccionada == 0:
                self.show_inventario()
            else:
                self.show_chat()

        # Asociar la función al evento de cambio de pestaña
        self.notebook.bind("<<NotebookTabChanged>>", cambiar_contenido)
        
       
    @dev_log({"clase":"UsuarioView"})    
    def show_inventario(self):
        """
        Muestra la interfaz gráfica para la gestión del inventario.

        Crea y organiza los siguientes elementos en la ventana principal:

        - Frames:
            - frame1: Contiene etiquetas y campos de entrada para interactuar con el inventario.
            - frame2: Contiene botones para agregar, eliminar, modificar, consultar, exportar y limpiar registros.
            - frame3: Contiene un Treeview para mostrar los registros del inventario.

        - Etiquetas y Campos de Entrada:
            - id_label, id_entry: Etiqueta y campo para el ID del registro.
            - marca_label, marca_entry: Etiqueta y campo para la marca del producto.
            - modelo_label, modelo_entry: Etiqueta y campo para el modelo del producto.
            - cantidad_label, cantidad_entry: Etiqueta y campo para la cantidad del producto.

        - Botones:
            - agregar_button: Agrega un nuevo registro al inventario.
            - eliminar_button: Elimina un registro del inventario.
            - modificar_button: Modifica un registro existente.
            - consultar_button: Consulta y filtra registros.
            - exportar_button: Exporta los registros a un archivo.
            - limpiar_button: Limpia los campos de entrada.

        - Treeview:
            - Muestra los registros del inventario con columnas para ID, Marca, Modelo y Cantidad.
            - Se vincula a un evento `<<TreeviewSelect>>` para manejar la selección de elementos.
        """
        
        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.frame_inferior)
        #self.frame_inferior.pack(expand=True, fill=tk.BOTH)

        frame1.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.columnconfigure(1,weight=1)
        frame1.columnconfigure(2,weight=2)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)
        frame1.rowconfigure(2,weight=1)
        frame1.rowconfigure(3,weight=1)
        frame1.rowconfigure(4,weight=1)
        
        #Frame 2: va ubicado en el ultimo row de Frame1 y es para los botones
        frame2 = ttk.Frame(frame1)
        frame2.grid(row=4, column=0,columnspan=4,sticky="nsew", padx=5, pady=0)
        frame2.columnconfigure(0,weight=1)
        frame2.columnconfigure(1,weight=1)
        frame2.columnconfigure(2,weight=1)
        frame2.columnconfigure(3,weight=1)
        frame2.columnconfigure(4,weight=1)
        frame2.columnconfigure(5,weight=1)
        frame2.columnconfigure(6,weight=1)
        frame2.rowconfigure(0,weight=1)

        # Frame 3: es para el item list de elementos,
        frame3 = ttk.Frame(self.frame_inferior)
        frame3.grid(row=1, column=0, sticky="new", padx=0, pady=0)
        frame3.columnconfigure(0,weight=1)
        frame3.rowconfigure(0,weight=1)

        # --- Etiquetas y campos de entrada --
        # Etiqueta y campo para el id
        id_label = ttk.Label(frame1, text="ID:")
        id_label.grid(row=0, column=0, padx=5, pady=10)
        self.id_entry = ttk.Entry(frame1)
        self.id_entry.grid(row=0, column=1, padx=5, pady=5)
        
        # Etiqueta y campo para el Marca
        marca_label = ttk.Label(frame1, text="Marca:")
        marca_label.grid(row=1, column=0, padx=5, pady=5)
        self.marca_entry = ttk.Entry(frame1)
        self.marca_entry.grid(row=1, column=1, padx=5, pady=5)

        # Etiqueta y campo para el Modelo
        modelo_label = ttk.Label(frame1, text="Modelo:")
        modelo_label.grid(row=2, column=0, padx=5, pady=5)
        self.modelo_entry = ttk.Entry(frame1)
        self.modelo_entry.grid(row=2, column=1, padx=5, pady=5)

        # Etiqueta y campo para la cantidad
        cantidad_label = ttk.Label(frame1, text="Cantidad:")
        cantidad_label.grid(row=3, column=0, padx=5, pady=5)
        self.cantidad_entry = ttk.Entry(frame1)
        self.cantidad_entry.grid(row=3, column=1, padx=5, pady=5)

        # --- Botones ---
        # Boton Agregar
        agregar_button = ttk.Button(frame2, text="Agregar", command=lambda:[self.agregar_registro(self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        agregar_button.grid(row=0, column=0, padx=5, pady=5)

        # Boton Eliminar
        eliminar_button = ttk.Button(frame2, text="Eliminar", command=lambda:[self.eliminar_registro(self.id_entry.get())])
        eliminar_button.grid(row=0, column=1, padx=5, pady=5)

        # Boton Modificar
        modificar_button = ttk.Button(frame2, text="Modificar", command=lambda:[self.modificar_registro(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        modificar_button.grid(row=0, column=2, padx=5, pady=5)

        # Boton Consultar
        consultar_button = ttk.Button(frame2, text="Consultar", command=lambda:[self.consultar_registros(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        consultar_button.grid(row=0, column=3, padx=5, pady=5)
        
        # Boton Exportar
        exportar_button = ttk.Button(frame2, text="Exportar", command=lambda:[self.exportar_registros(self.id_entry.get(),self.marca_entry.get(), self.modelo_entry.get(), self.cantidad_entry.get())])
        exportar_button.grid(row=0, column=4, padx=5, pady=5)
        
        # Boton Limiar Campos
        limpiar_button = ttk.Button(frame2, text="Limpiar", command=lambda:[self.limpiar_campos()])
        limpiar_button.grid(row=0, column=5, padx=5, pady=5)

        # --- Treeview ---
        self.treeview = ttk.Treeview(frame3, columns=("ID", "Marca", "Modelo", "Cantidad"), show="headings")
        self.treeview.heading("ID", text="ID")
        self.treeview.heading("Marca", text="Marca")
        self.treeview.heading("Modelo", text="Modelo")
        self.treeview.heading("Cantidad", text="Cantidad")
        self.treeview.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # Vincular evento de selección en el treevew
        self.treeview.bind("<<TreeviewSelect>>", self.on_tree_select)
        
        # Actualizar el treeview
        self.actualizar_view(self.treeview)
   
    @dev_log({"clase":"UsuarioView"})    
    def show_chat(self):
        """
        Muestra la interfaz gráfica para entrar en chat con algun administrador.
        
        """
        
        def actualizar_mensajes():
            
            respuesta = self.controller.get_mensajes_usuario()
            if respuesta.get_status():
                nuevos_mensajes = respuesta.get_registros()
                
                for item in treeview_mensajes.get_children():
                    treeview_mensajes.delete(item)

                # Insertar los nuevos mensajes
                for mensaje in nuevos_mensajes:
                    treeview_mensajes.insert("", END, text = "", values=(mensaje['remitente'], mensaje['contenido'], mensaje['fecha_hora']))
            else:
                print(f"Error: {respuesta.get_error}")
            
        # Función para simular el envío de un mensaje (reemplaza con tu lógica real)
        def enviar_mensaje():
            """
            Envia mensaje al chat del usuario seleccionado
            """
            mensaje = entry_mensaje.get()
            respuesta = self.controller.enviar_mensaje_usuario(mensaje)
            if respuesta.get_status():
                actualizar_mensajes()
                entry_mensaje.delete(0, tk.END)
            else:
                print(f"Error: {respuesta.get_error()}")
            
                
        # --- Creacion de Frames ---
        # Frame 1: es para los campos y los botones
        frame1 = ttk.Frame(self.frame_inferior)
        #self.frame_inferior.pack(expand=True, fill=tk.BOTH)

        frame1.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        frame1.columnconfigure(0,weight=1)
        frame1.rowconfigure(0,weight=1)
        frame1.rowconfigure(1,weight=1)
        
    
        # Treeview para los mensajes
        treeview_mensajes = ttk.Treeview(frame1, columns=("Remitente", "Mensaje", "Fecha/Hora"), show="headings")
        treeview_mensajes.heading("Remitente", text="Remitente")
        treeview_mensajes.heading("Mensaje", text="Mensaje")
        treeview_mensajes.heading("Fecha/Hora", text="Fecha/Hora")
        treeview_mensajes.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)

        for col in treeview_mensajes["columns"]:
            print(col)
            if col == "Mensaje":
                size = 2000
            elif col == "Fecha/Hora":
                size = 400
            else:
                size = 100
                
            treeview_mensajes.column(col, width=min(treeview_mensajes.column(col, "width"), size)) 
    
    
        frame2 = ttk.Frame(frame1)
        frame2.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        frame2.columnconfigure(0,weight=4)
        frame2.columnconfigure(1,weight=1)
        frame2.columnconfigure(2,weight=1)
        frame2.rowconfigure(0,weight=1)
        
        # Entry para escribir el mensaje
        entry_mensaje = tk.Entry(frame2)
        entry_mensaje.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)

        # Botón para actualizar mensajes
        boton_actualizar = tk.Button(frame2, text="Actualizar Mensajes", command=actualizar_mensajes)
        boton_actualizar.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)

        # Botón para enviar el mensaje
        boton_enviar = tk.Button(frame2, text="Enviar", command=enviar_mensaje)
        boton_enviar.grid(row=0, column=2, sticky="nsew", padx=0, pady=0)

        # Iniciar las actualizaciones automáticas al abrir la ventana
        frame1.after(0, actualizar_mensajes)
    
   
    @dev_log({"clase":"UsuarioView"})
    def on_tree_select(self, event):
        """
        Se encarga se la seleccion de un item en el Treeview
        
        Este metodo es llamado cuando un item en el Treeview es seleccionado. Este llena los
        calores de los campos Entry con los datos del item seleccionado. 

        Args:
            event (tk.Event): El evento que acciona la seleccion
        """
        #Cuando esta en 'bind' un evento es accionado por diferentes motivos, no solo cuando es seleccionado,
        #Tambien se activa cuando se deselecciona por actualizar, o agregar elementos, eso genera un error o warning, pues deja de encontrarlo
        #Para evitar este error se agrega un try
        try:
            
            item = self.treeview.selection()[0]
            values = self.treeview.item(item, "values")
            self.id_entry.delete(0, tk.END)
            self.id_entry.insert(0, values[0])
            self.marca_entry.delete(0, tk.END)
            self.marca_entry.insert(0, values[1])
            self.modelo_entry.delete(0, tk.END)
            self.modelo_entry.insert(0, values[2])
            self.cantidad_entry.delete(0, tk.END)
            self.cantidad_entry.insert(0, values[3])
        except Exception as e:
            print(f"Debido a cambios en las listas, la seleccion anterior se deselecciono de la lista")
    
    @dev_log({"clase":"UsuarioView"})
    def agregar_registro(self, marca, modelo, cantidad):
        """
        Agrega un registro nuevo al inventario
        Add a new inventory record.

        Args:
            marca (str): La marca del nuevo item.
            modelo (str): El modelo del nuevo item.
            cantidad (int): La cantidad del nuevo item.
        """
        respuesta = self.controller.agregar_registro(marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "agregar")

    @dev_log({"clase":"UsuarioView"})
    def eliminar_registro(self, id):
        """
        Elimina un registro del inventario

        Args:
            id (int): El ID del registro a eliminar
        """
        respuesta = self.controller.eliminar_registro(id)
        self.handle_respuesta(respuesta, "eliminar")    
          
    @dev_log({"clase":"UsuarioView"}) 
    def modificar_registro(self, id, marca, modelo, cantidad):
        """
        Modifica un registro existente en el inventario.

        :param id: El ID del registro a modificar.
        :param marca: La nueva marca del producto.
        :param modelo: El nuevo modelo del producto.
        :param cantidad: La nueva cantidad en inventario.
        """
        respuesta = self.controller.modificar_registro(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "modificar")

    @dev_log({"clase":"UsuarioView"})
    def consultar_registros(self, id, marca, modelo, cantidad):
        """
        Consulta registros en el inventario según los criterios especificados.

        :param id: El ID del registro a buscar (opcional).
        :param marca: La marca del producto a buscar (opcional).
        :param modelo: El modelo del producto a buscar (opcional).
        :param cantidad: La cantidad mínima en inventario a buscar (opcional).
        """
        respuesta = self.controller.consultar_registros(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "consultar")

    @dev_log({"clase":"UsuarioView"})
    def exportar_registros(self, id, marca, modelo, cantidad):
        """
        Exporta los registros del inventario que cumplen los criterios especificados.

        :param id: El ID del registro a exportar (opcional).
        :param marca: La marca del producto a exportar (opcional).
        :param modelo: El modelo del producto a exportar (opcional).
        :param cantidad: La cantidad mínima en inventario a exportar (opcional).
        """
        respuesta = self.controller.exportar_registros(id, marca, modelo, cantidad)
        self.handle_respuesta(respuesta, "exportar")

    @dev_log({"clase":"UsuarioView"})
    def handle_respuesta(self,respuesta,tipo):
        """
        Maneja la respuesta de una operación (agregar, modificar, eliminar, consultar, exportar).

        :param respuesta: Objeto de respuesta con información sobre el resultado de la operación.
        :param tipo: El tipo de operación realizada.
        """
        print("Inside handle")
        error = respuesta.get_error()
        textoExito = ""
        textoFracaso= ""
        if tipo == 'agregar':
            textoExito = "El registro se ha agregado con exito"
            textoFracaso = f"Ups! Algo salio mal al agregar el registro: {error}"
        elif tipo == 'modificar':
            textoExito = "El registro se ha modificado con exito"
            textoFracaso = f"Ups! Algo salio mal al modificar el registro: {error}"
        elif tipo == 'eliminar':
            textoExito = "El registro se ha eliminado con exito"
            textoFracaso = f"Ups! Algo salio mal al eliminar el registro: {error}"
        elif tipo == 'consultar':
            textoExito = "La consulta se ha realizado con exito"
            textoFracaso = f"Ups! Algo salio mal al realizar la consulta: {error}"
        elif tipo == 'exportar':
            textoExito = "Se han exportado los datos con exito"
            textoFracaso = f"Ups! Algo salio mal al exportar la consulta: {error}"
        else:
            textoExito = f"Algo anda mal, favor de contactar al desarrollador: {tipo} "
            textoFracaso = f"Ups! Algo salio mal al agregar el registro: {error}"
        
        print("Error calculated handle")
        try:
            if respuesta.get_status() == 1 :
                if tipo in ["consultar", "exportar"]:
                    self.actualizar_view(self.treeview,respuesta.get_registros())
                else:
                    self.actualizar_view(self.treeview)
                    
                print("Actualizando view")
                #showinfo("Informacion",textoExito)
            else:
                #showwarning("Advertencia!",textoFracaso)
                pass
        except:
            #showwarning("Advertencia",textoFracaso)
            pass
    
    @dev_log({"clase":"UsuarioView"})
    def limpiar_campos(self):
        """
        Limpia los campos de entrada de datos en la interfaz de usuario.
        """
        try:
            self.id_entry.delete(0, tk.END)
            self.marca_entry.delete(0, tk.END)
            self.modelo_entry.delete(0, tk.END)
            self.cantidad_entry.delete(0, tk.END)
        except Exception as e:
            print(f"No se pudieron Limpiar los campos {e}")
      
    @dev_log({"clase":"UsuarioView"})
    def actualizar_view(self, tree, registros_nuevos = None):
        """
        Actualiza la vista del árbol (treeview) con los registros del inventario.

        :param tree: El widget Treeview a actualizar.
        :param registros_nuevos: Lista opcional de nuevos registros para mostrar. 
                                Si es None, se obtendrán los registros del controlador.
        """
        
        registros = tree.get_children()
        for registro in registros:
            tree.delete(registro)
        
        if registros_nuevos is None:
            respuesta = self.controller.get_registros()
            
            if respuesta.get_status() == 1:
                registros_nuevos = respuesta.get_registros()
            else: 
                showwarning("Error:",respuesta.get_error())
                
        if not registros_nuevos is None: 
                 
            for registro in registros_nuevos:
                tree.insert('', END, text="" ,values=(registro["id"], registro["marca"], registro["modelo"], registro["cantidad"]))
