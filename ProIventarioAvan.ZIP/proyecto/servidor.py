import threading
import json
import socket
from modelo import InventarioModel
from decorador_dev_log import dev_log
import socket
import threading
import socketserver
from respuesta import Respuesta

def procesar_consulta(data):
    
    model = InventarioModel()
    
    comandos = data.split("<>")  # Separa el comando por espacios
    print(comandos)
    # De aceurdo al primer comando realizar la accione en el modelo
    accion = comandos[0].split(":")[1]
    
    respuesta = Respuesta()
    if accion == "LOGIN":
        ## el resto de los comandos
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        contrasena = comandos[3].split(":")[1]
        #Utilizar accion correspondietne 
        respuesta = model.verifica_usuario(accion,tipo,usuario,contrasena)
        
    elif accion == "TABLAS":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        respuesta = model.get_tablas(accion,tipo, usuario)
    elif accion == "AGREGAR":
        
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        marca = comandos[3].split(":")[1]
        modelo = comandos[4].split(":")[1]
        cantidad = comandos[5].split(":")[1]
        respuesta = model.agregar_registro(accion,tipo,usuario,marca,modelo,cantidad)
    elif accion == "MODIFICAR":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        id = comandos[3].split(":")[1]
        marca = comandos[4].split(":")[1]
        modelo = comandos[5].split(":")[1]
        cantidad = comandos[6].split(":")[1]
        respuesta = model.modificar_registro(accion,tipo,usuario,id,marca,modelo,cantidad)
    elif accion == "ELIMINAR":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        id = comandos[3].split(":")[1]
        respuesta = model.eliminar_registro(accion,tipo,usuario,id)
    elif accion == "CONSULTAR":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        id = comandos[3].split(":")[1]
        marca = comandos[4].split(":")[1]
        modelo = comandos[5].split(":")[1]
        cantidad = comandos[6].split(":")[1]
        respuesta = model.consultar_registros(accion,tipo,usuario,id,marca,modelo,cantidad)
    elif accion == "EXPORTAR":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        id = comandos[3].split(":")[1]
        marca = comandos[4].split(":")[1]
        modelo = comandos[5].split(":")[1]
        cantidad = comandos[6].split(":")[1]
        respuesta = model.exportar_registros(accion,tipo,usuario,id,marca,modelo,cantidad)
    elif accion == "GETREGISTROS":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        respuesta = model.get_registros(accion,tipo,usuario)
    elif accion == "GETLOGS":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        respuesta = model.get_logs(accion,tipo,usuario)
    elif accion == "CONSULTALOGS":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        busqueda_tipo = comandos[3].split(":")[1]
        busqueda_usuario = comandos[4].split(":")[1]
        busqueda_accion = comandos[5].split(":")[1]
        fecha = comandos[6].split(":")[1]
        respuesta = model.consultar_logs(accion,tipo,usuario,busqueda_tipo,busqueda_usuario,busqueda_accion,fecha)
    elif accion == "EXPORTARLOGS":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        busqueda_tipo = comandos[3].split(":")[1]
        busqueda_usuario = comandos[4].split(":")[1]
        busqueda_accion = comandos[5].split(":")[1]
        fecha = comandos[6].split(":")[1]
        respuesta = model.exportar_logs(accion,tipo,usuario,busqueda_tipo,busqueda_usuario,busqueda_accion,fecha)
    
    elif accion == "PING":
        respuesta.set_status(1)
        respuesta.set_error("PONG")
    elif accion == "DETENER":
        respuesta.set_status(1)
        respuesta.set_error("NONE")
        
    elif accion == "ENVIAMENSAJE":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        destinatario = comandos[3].split(":")[1]
        mensaje = comandos[4].split(":")[1]
        respuesta = model.enviar_mensaje(accion,tipo,usuario,destinatario,mensaje)
    elif accion == "GETMENSAJES":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        destinatario = comandos[3].split(":")[1]
        respuesta = model.obtener_mensajes_chat(accion,tipo,usuario,destinatario,)
    elif accion == "GETUSUARIOS":
        tipo = comandos[1].split(":")[1]
        usuario = comandos[2].split(":")[1]
        respuesta = model.get_usuarios(accion,tipo,usuario,)
    
    else:
        respuesta.set_status(0)
        respuesta.set_error(f"Comando desconocido: {accion}")
    print(respuesta)
    response = respuesta.to_json()
    print(f"Sending {response}")
    return response

class MyTCPHandler(socketserver.BaseRequestHandler):
    """
    MyTCPHandler nos ayuda a administrar las diferentes consultas que se le hacen al rsercidor
    
    :param todos: Los parametros de entrada los define la clase BaseRequestHandler.
    :type model: Los tupos de datos los define BaseRequestHandler
    """
    
    def handle(self):
        """ Metodo principal para administrar los diferentes tipos de consultas.
        dependiendo del a consulta es el metodo que se utiliza del modelo,
        el cual respinde con una respuesta tipo REspuesta para ser convertida a json y 
        enviarla de vuelta al cliente
        """
        self.data = self.request.recv(1024).strip()
        
        print(f"Cliente conectado desde {self.client_address[0]}")

        consulta = self.data.decode()
        respuesta = procesar_consulta(consulta)

        self.request.sendall(respuesta.encode())
        
class Servidor:
    """Clase para encender un servidor. Solo un administrador puede iniciarlo y 
    actualmente no tiene forma de administrar el host nni los puertos
    siempre quda en localhost con puerto en 4924
    """
    @dev_log()
    def __init__(self):
        """Inicializacion del servidor y parametros que se utilicen.
        """
        self.host = socket.gethostbyname(socket.gethostname())
        self.puerto = 9999
        self.socket = None
        self.cliente = None
        self.server_thread = None
        self.shutdown_event = threading.Event()
        
        
    @dev_log()
    def verificar_servidor(self):
        """Metodo utilizado para verificar que el servidor este encendido
        """
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                self.socket.connect(('localhost', self.puerto))  # Intenta conectar al servidor
            return True
        except ConnectionRefusedError:
            return False
        
    def serve(self,evento_parada):
        """Metodo utilizado por el tread para tener el servidor encendido.
        Aqui se utiliza el TCP Handler para administrar las llamadas.
        """
        HOST, PORT = "localhost", self.puerto

        with socketserver.ThreadingTCPServer((HOST, PORT), MyTCPHandler) as server:
            print(f"Servidor escuchando en {HOST}:{PORT}")
            while not evento_parada.is_set():  
                server.handle_request()  # Mantiene el servidor en ejecución
            
            
        
    @dev_log()
    def iniciar_servidor(self):
        """Metodo llamado por el adminsitrador para iniciar el servidor en un thread y 
        asi el servidor quede encendido indefinidamente
        (Hasta que el mismo realice una consulta de ACCION:DETENER)
        """
        self.server_thread = threading.Thread(target=self.serve, args=(self.shutdown_event,)).start()  # Crear el hilo
        return [True, ""]

    
    @dev_log()
    def detener_servidor(self):
        """Este metodo lo llama el administrador luego de haber realizado
        la consulta de ACCION DETENER.
        aqui se termina el thread.
        """
        try:
            self.shutdown_event.set()
            return [True,"Servidor cerrado"]
        except Exception as e:
            return [False, str(e) ]
