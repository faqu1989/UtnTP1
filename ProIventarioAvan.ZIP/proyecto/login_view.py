import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from admin_view import AdminView
from usuario_view import UsuarioView
from decorador_dev_log import dev_log

class LoginView:
    """
    Vista principal del sistema de inventario. Maneja la interfaz gráfica del login.
    A partir de aqui se decide si se muestra la ventana de usuario o de administrador.

    :param root: La ventana raíz de la aplicación.
    :type root: tk.Tk
    :param controller: El controlador que gestiona la lógica de negocio.
    :type controller: ControladorInventario 
    """
    @dev_log({"clase":"LoginView"})
    def __init__(self, root, controlador):
        """
        Inicializa el  LoginView.

        Args:
            root (tk.Tk): La ventana raiz de la aplicacionThe root window of the application.
            controller (InventarioController): El controlador responsable de la logica.
        """
        self.root = root
        self.controlador = controlador
        root.title("Inicio de Sesión")

        # Elementos de la interfaz
        tk.Label(self.root, text="Usuario:").grid(row=0, column=0)
        tk.Label(self.root, text="Contraseña:").grid(row=1, column=0)

        self.usuario_entry = tk.Entry(self.root)
        self.contrasena_entry = tk.Entry(self.root, show="*")
        self.usuario_entry.grid(row=0, column=1)
        self.contrasena_entry.grid(row=1, column=1)

        tk.Button(self.root, text="Iniciar Sesión", command=self.verificar_credenciales).grid(row=2, column=0, columnspan=2)

        # Datos de administradores en memoria
        self.admins = {
            "admin1": "admin1",
            "admin2": "admin2",
            "facudo": "facundo"
        }
        
    @dev_log({"clase":"LoginView"})
    def verificar_credenciales(self):
        """
        Verifica si las credecniales pertenecen a un usuario o a un administrador

        """
        usuario = self.usuario_entry.get()
        contrasena = self.contrasena_entry.get()

        
        # Verificar si es administrador
        if usuario in self.admins and self.admins[usuario] == contrasena:
            self.abrir_ventana_admin(usuario)
            return

        usuario_verificado = self.controlador.verifica_usuario(usuario, contrasena)

        if usuario_verificado.get_status():
            self.abrir_ventana_usuario(usuario)
        else:
            # En caso de que las credenciales no correspondan ni a un usuario ni administrador, entonce se muestra la leyenda
            # Credenciales incorrectas
            tk.Label(self.root, text=usuario_verificado.get_error(), fg="red").grid(row=3, column=0, columnspan=2)

    @dev_log({"clase":"LoginView"})
    def abrir_ventana_admin(self, usuario):
        """
        En caso de que las credenciales correspondan a un administrador, destruye el view del login y abre un View de AdminView

        """
        self.controlador.set_usuario(usuario)
        self.controlador.set_tipo("Admin")
        self.root.destroy()  # Cerrar la ventana de inicio de sesión
        new_root = ThemedTk(theme="arc")
        AdminView(new_root,self.controlador)
        new_root.mainloop()
        """
        .. autoclass:: AdminView
            :members:
            :undoc-members:
            :show-inheritance:
        """

    @dev_log({"clase":"LoginView"})
    def abrir_ventana_usuario(self, usuario):
        """
        En caso de que las credenciales correspondan a un usuario, destruye el view del login y abre un View de UsuarioView

        """
        self.controlador.set_usuario(usuario)
        self.controlador.set_tipo("Usuario")
        self.root.destroy()  # Cerrar la ventana de inicio de sesión
        new_root = ThemedTk(theme="arc")
        UsuarioView(new_root,self.controlador)
        new_root.mainloop()
        """
        .. autoclass:: UsuarioView
            :members:
            :undoc-members:
            :show-inheritance:
        """