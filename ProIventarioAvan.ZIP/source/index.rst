.. ProyectoInventarioPython documentation master file, created by
   sphinx-quickstart on Sun Jul 21 18:39:54 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentación del Sistema de Inventario
=======================================

Este documento proporciona una descripción detallada del sistema de inventario, incluyendo sus módulos principales y sus funcionalidades.
Detallando en la funcionalidad de cada uno de los metodos implementados. Presiona en el modulo de interes para ver mas detalles 

Es importante mencionar que todas las clases utilizadas en el desarrollo implementan decorador_dev_log, el cual es un decorador que nos permite visualizar en consola el flujo del codigo
y adicionalmente nos arroja un dev_log.log con informacion relevante.

A continuacion se detalla cada archivo utilizado en el desarrollo

.. toctree::
   :maxdepth: 2

   main

Este Modulo es el punto de entrada principal de la aplicación de inventario. 
Esta sección se ejecuta cuando el script se llama directamente (no se importa como módulo).
Inicializa el controlador y el login view y luego inicia el bucle principal de la interfaz gráfica.


.. toctree::
   :maxdepth: 2

   login_view

Loginview se encarga de adminsitrar el Login, aqui se tras hacer entrada de datos se dirige al UsuarioView o Admin view, segun corresponda

.. toctree::
   :maxdepth: 2

   usuario_view

Esta clase es la interfaz grafica dirigida al usuario, aqui el usuario (si el servidor esta encendido) puede agregar, eliminar, modificar, consultar o exportar registros. 
Cuenta con un boton adicional para limpiar los campos.



.. toctree::
   :maxdepth: 2

   admin_view

Esta clase es la interfaz grafica de el administrador, aqui el administrador tiene tres pestañas, inventario ( tiene el mismo uso qu eel usuario); la pestaña Registro de log, 
donde el adminstrador puede ver las acciones que se han relizado en la base de datos; y la pestaña servidor donde el dministrador puede iniciar el servidor.

Tanto la pestaña inventario ( para usuario como administrador) como el registro de log solo funcionan si un administrador a iniciado el servidor.

.. toctree::
   :maxdepth: 2

   controlador

Esta clase que maneja las operaciones de los usuarios y administradores de manera adecuada.

.. toctree::
   :maxdepth: 2

   cliente

Esta esta clase es la que conecta al os usuarios y administradores con el servidor 

.. toctree::
   :maxdepth: 2

   modelo

Esta clase es la que se encarga de administrar todas las consultas que se le realizan a la base de datos. El modelo solo es utilizado por el servidor.

.. toctree::
   :maxdepth: 2

   respuesta

Esta clase representa la respuesta de una operación, incluyendo estado, errores y registros

.. toctree::
   :maxdepth: 2

   servidor

La clase servidor solo la puede utilizar un administrador, aqui se inicia el servidor mediante un thread para asegurar el funcionamiento continuo. 
Las consultas son manejadas por un helper.

.. toctree::
   :maxdepth: 2

   validador

La clase Validador ayuda a validar la entrada de los datos, aqui se hace uso de Regex.

.. toctree::
   :maxdepth: 2

   observador

El observador se implementa sobre los metodos del Modelo, esta clase tiene la utilidad de llevar un registro de las acciones realizadas.

.. toctree::
   :maxdepth: 2

   decorador_dev_log

El decorador que nos permite visualizar en consola el flujo del codigo
y adicionalmente nos arroja un dev_log.log con informacion relevante.