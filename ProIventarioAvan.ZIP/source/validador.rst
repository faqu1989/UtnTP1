.. module:: validador

.. _validador:

Módulo Validador
----------------

Este módulo contiene la clase  ``Validador``,
Es utilizado para validar los inputs que realiza el cliente.

Clase Validador
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: Validador
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__
