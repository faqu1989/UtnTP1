.. module:: controlador

.. _controlador:

Módulo controlador
------------------

Este módulo contiene la clase ``InventarioController``, que se encarga de la lógica  del sistema de inventario tanto para usuarios como para administradores. Aqui se implementan los metodos ``__init__`` para
inicializar el controlador, asi como los metodos mas especificos de acuerdo a la accion a realizar por el usuario o administrador.


Clase InventarioController
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: InventarioController

   .. automethod:: __init__
   :members:
   :undoc-members:
   :show-inheritance:

