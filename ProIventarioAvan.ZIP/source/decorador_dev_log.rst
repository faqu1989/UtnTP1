.. module:: decorador_dev_log

.. _decorador_dev_log:

Módulo dev_log
--------------

Decorator para registrar logs de desarrollo de funciones.

Este decorador registra información detallada sobre las funciones a las que se aplica,
incluyendo su nombre, argumentos posicionales y argumentos de palabra clave. La información
se imprime en la consola y en un archivo llamado dev_log.log para fines de depuración y desarrollo.

funcion dev_log
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: dev_log
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__
