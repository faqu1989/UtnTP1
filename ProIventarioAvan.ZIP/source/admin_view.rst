.. module:: admin_view

.. _admin_view:

Módulo AdminView
-----------------

Este módulo contiene la clase ``AdminView``, Maneja la interfaz grafica y la interaccion con el controlador de los administradores.

Los administradores que inician sesion aqui lo lograron tras hacer so de las credenciales guardadas en memoria.

Estas credeciales corresponden a 'admin1', 'admin2', tanto como para usuario como para contraseña

Clase AdminView
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: AdminView
   :members:
   :undoc-members:
   :show-inheritance:

   .. automethod:: __init__
