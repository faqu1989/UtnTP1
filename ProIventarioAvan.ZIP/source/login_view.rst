.. module:: login_view

.. _login_view:

Módulo LoginView
-----------------

Este módulo contiene la clase ``LoginView``, Maneja la interfaz grafica para el inicio de sesion. Tanto par ausuarios como para administradores

Las credenciales de los administradores se cargan desde memoria, mientras que las credenciales de los usuarios se cargan desde la base de datos que solo un administrador puede iniciar en un servidor local.


Clase LoginView
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: LoginView
   :members:
   :undoc-members:
   :show-inheritance:

   .. automethod:: __init__
