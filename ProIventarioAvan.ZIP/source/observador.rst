.. module:: observador

.. _observador:

Módulo observador
------------------

Este módulo contiene la clase  ``ObservadorLog`` y la funcion ``registrar_accion``.

Esta funcion es utilizada para registrar las acciones realizadas en el modelo utilizando el patron observador.
Todas los metodos utilizados en la clase ``InventarioModel``, implementan ``registrar_accion``,
 para llevar un log en la base de datos de las acciones realizadas en ella.

Este log puede ser visto solo por los administradores en la pestaña de Log.


Clase ObservadorLog
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: ObservadorLog
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__
