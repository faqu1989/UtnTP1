.. _main:

Módulo main
-----------

Este módulo es el punto de entrada principal de la aplicación. Se encarga de inicializar los componentes necesarios (controlador, modelo, vista) y lanzar la interfaz gráfica de usuario (GUI).

.. automodule:: main
   :members:
   :undoc-members:


Aqui se realiza la implementacion de las clases de la siguiente forma :

.. code-block:: python

    # Definición del modelo (datos)
      cliente = Cliente()
      """
      .. autoclass:: Cliente
         :members:
         :undoc-members:
         :show-inheritance:
      """
      
      # Definición del controlador (lógica)
      controller = InventarioController(cliente)
      """
      .. autoclass:: InventarioController
         :members:
         :undoc-members:
         :show-inheritance:
      """

      # Inicia el bucle principal de la interfaz gráfica (Tkinter)
      app = LoginView(root,controller)
      """
      .. autoclass:: LoginView
         :members:
         :undoc-members:
         :show-inheritance:
      """


.. note::
   Este módulo no contiene clases, lo docuementado aqui es la implementacion incial de los componentes necesarios 