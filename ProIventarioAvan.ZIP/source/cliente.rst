.. module:: cliente

.. _cliente:

Módulo Cliente
--------------

Clase que representa un cliente para interactuar con un servidor a 
través de sockets.

Clase Cliente 
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: Cliente
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__
