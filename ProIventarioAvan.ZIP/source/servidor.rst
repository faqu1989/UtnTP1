.. module:: servidor

.. _servidor:

Módulo Servidor
---------------

Clase para encender un servidor. Solo un administrador puede iniciarlo y 
actualmente no tiene forma de administrar el host nni los puertos
siempre quda en localhost con puerto en 4924


Clase Servidor
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: Servidor
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__

la clase servidor, hace uso de una clase auxiliar:


Clase MyTCPHandler
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: MyTCPHandler
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__

Y esta clase ``MyTCPHandler``, hace uso de una funcion auxiliar 
``procesar_consluta`` la cual se encarga de administrar las consultas recibidas al servidor.
preprocesar las salidas que se enviaran al cliente antes de ser enviadas por MyTCPHandler