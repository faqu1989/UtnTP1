.. module:: usuario_view

.. _usuario_view:

Módulo UsuarioView
-------------------

Este módulo contiene la clase ``UsuarioView``, Maneja la interfaz grafica y la interaccion con el controlador de los usuarios.
Los usuarios solo pueden acceder aqui si un administrador a iniciado el servidor.

Inicialmente cuando un administrador genera la base de datos, se cargan 3 usuarios en la base de datos, estos tienen como nombre y como contraseña: 'usuario1', 'usuario2' y 'usuario0'

Clase UsuarioView
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: UsuarioView
   :members:
   :undoc-members:
   :show-inheritance:

   .. automethod:: __init__
