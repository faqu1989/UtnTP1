# Controlador
class InventarioController:
    """
    Clase que maneja las operaciones de inventario, actuando como intermediario entre la interfaz de usuario y el modelo de datos.

    :param model: El modelo de datos que representa el inventario.
    :type model: InventarioModel (o una clase similar)
    """

    def __init__(self, model):
        self.model = model

    def agregar_registro(self, marca, modelo, cantidad):
        """
        Agrega un nuevo registro al inventario.

        :param marca: La marca del producto.
        :type marca: str
        :param modelo: El modelo del producto.
        :type modelo: str
        :param cantidad: La cantidad disponible del producto.
        :type cantidad: int
        :return: El resultado de la operación de agregar (éxito/fracaso).
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        return self.model.agregar_registro(marca, modelo, cantidad)

    def modificar_registro(self, id, marca, modelo, cantidad):
        """
        Modifica un registro existente en el inventario.

        :param id: El identificador único del registro a modificar.
        :type id: int
        :param marca: La nueva marca del producto.
        :type marca: str
        :param modelo: El nuevo modelo del producto.
        :type modelo: str
        :param cantidad: La nueva cantidad disponible del producto.
        :type cantidad: int
        :return: El resultado de la operación de modificar (éxito/fracaso).
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        return self.model.modificar_registro(id, marca, modelo, cantidad)

    def eliminar_registro(self, id):
        """
        Elimina un registro del inventario.

        :param id: El identificador único del registro a eliminar.
        :type id: int
        :return: El resultado de la operación de eliminar (éxito/fracaso).
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        return self.model.eliminar_registro(id)

    def consultar_registros(self, id="", marca="", modelo="", cantidad=""):  # Valores por defecto para filtros opcionales
        """
        Consulta los registros del inventario, permitiendo filtrar por ID, marca, modelo y/o cantidad.
        Si el valor de ID es ingresado filtra por ID,
        Si el valor de marca esta indicado, filtra por marca
        Si el valor de modelo esta indicado, filtra por modelo.
        SI el valor de candidad esta especificado, filtra por aquellso que sean menor o igual a la cantidad especidicada.
        
        
        :param id: (Opcional) El ID del registro a buscar.
        :type id: str
        :param marca: (Opcional) La marca del producto a buscar.
        :type marca: str
        :param modelo: (Opcional) El modelo del producto a buscar.
        :type modelo: str
        :param cantidad: (Opcional) La cantidad del producto a buscar.
        :type cantidad: str
        :return: El resultado de la consulta, incluyendo los registros encontrados y el estado de la operación.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        return self.model.consultar_registros(id, marca, modelo, cantidad)

    def exportar_registros(self, id="", marca="", modelo="", cantidad=""):  # Valores por defecto para filtros opcionales
        """
        Exporta los registros del inventario a un archivo de texto, permitiendo filtrar por ID, marca, modelo y/o cantidad.
        Si el valor de ID es ingresado filtra por ID,
        Si el valor de marca esta indicado, filtra por marca
        Si el valor de modelo esta indicado, filtra por modelo.
        SI el valor de candidad esta especificado, filtra por aquellso que sean menor o igual a la cantidad especidicada.
        

        :param id: (Opcional) El ID del registro a buscar.
        :type id: str
        :param marca: (Opcional) La marca del producto a buscar.
        :type marca: str
        :param modelo: (Opcional) El modelo del producto a buscar.
        :type modelo: str
        :param cantidad: (Opcional) La cantidad del producto a buscar.
        :type cantidad: str
        :return: El resultado de la consulta, indicando si la exportación fue exitosa.
        :rtype: Respuesta (o una clase similar que encapsula el resultado)
        """
        respuesta = self.model.consultar_registros(id, marca, modelo, cantidad)
        if respuesta.get_status() == 1:
                            
            if id =="":
                id = "ID"
            if marca == "":
                marca = "MK"
            if modelo == "":
                modelo = "MD"
            if cantidad == "":
                cantidad = "QT"
            with open(f'inventariado_{id}_{marca}_{modelo}_{cantidad}.txt', 'w') as f:
                for r in respuesta.get_registros():
                    f.write(f"{r.id}, {r.marca}, {r.modelo}, {r.cantidad}\n")
                    
        return respuesta

    def get_registros(self):
        """
        Obtiene todos los registros del inventario.

        :return: Una lista de registros de inventario.
        :rtype: list
        """
        registros = self.model.get_registros()
        return registros

   