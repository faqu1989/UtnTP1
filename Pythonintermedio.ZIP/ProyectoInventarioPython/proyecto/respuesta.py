class Respuesta:
    """ 
    Clase que representa la respuesta de una operación, incluyendo estado, errores y registros.

    Atributos:
        status (int): Código de estado de la operación (0: éxito, otros: error).
        error (str): Mensaje de error en caso de fallo.
        registros (list): Lista de registros resultantes de la operación.
    """

    def __init__(self):
        """
        Inicializa una nueva instancia de Respuesta.
        """
        self.status = 0
        self.error = ""
        self.registros = []

    def set_status(self, status: int) -> int:
        """
        Establece el código de estado de la respuesta.

        Args:
            status: Nuevo código de estado.

        Returns:
            El código de estado establecido.
        """
        self.status = status
        return self.status

    def set_error(self, error: str) -> str:
        """
        Establece el mensaje de error de la respuesta.

        Args:
            error: Nuevo mensaje de error.

        Returns:
            El mensaje de error establecido.
        """
        self.error = error
        return self.error

    def set_registros(self, registros: list) -> list:
        """
        Establece la lista de registros de la respuesta.

        Args:
            registros: Nueva lista de registros.

        Returns:
            La lista de registros establecida.
        """
        self.registros = registros
        return self.registros

    def get_status(self) -> int:
        """
        Obtiene el código de estado de la respuesta.

        Returns:
            El código de estado actual.
        """
        return self.status

    def get_error(self) -> str:
        """
        Obtiene el mensaje de error de la respuesta.

        Returns:
            El mensaje de error actual.
        """
        return self.error

    def get_registros(self) -> list:
        """
        Obtiene la lista de registros de la respuesta.

        Returns:
            La lista de registros actual.
        """
        return self.registros

    def append_registro(self, registro) -> list:
        """
        Agrega un nuevo registro a la lista de registros.

        Args:
            registro: El registro a agregar.

        Returns:
            La lista de registros actualizada.
        """
        self.registros.append(registro)
        return self.registros