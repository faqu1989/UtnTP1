import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk

from interfaz import InventarioView  # Importa la vista (interfaz gráfica)
from controlador import InventarioController  # Importa el controlador (lógica)
from modelo import InventarioModel           # Importa el modelo (datos)


# Aplicación principal
if __name__ == "__main__":
    """
    Punto de entrada principal de la aplicación de inventario.

    Esta sección se ejecuta cuando el script se llama directamente (no se importa como módulo).
    Inicializa el modelo, la vista y el controlador, y luego inicia el bucle principal de la interfaz gráfica.
    """

    # Uso de ThemedTk para aplicar temas visuales
    root = ThemedTk(theme="arc")
    root.title("Sistema de Inventario")  # Agrega un título a la ventana principal

    # Definición del modelo (datos)
    model = InventarioModel()
    """
    .. autoclass:: InventarioModel
       :members:
       :undoc-members:
       :show-inheritance:
    """

    # Definición del controlador (lógica)
    controller = InventarioController(model)
    """
    .. autoclass:: InventarioController
       :members:
       :undoc-members:
       :show-inheritance:
    """

    # Definición de la vista (interfaz gráfica)
    view = InventarioView(root, controller)  # Pasa el controlador a la vista
    """
    .. autoclass:: InventarioView
       :members:
       :undoc-members:
       :show-inheritance:
    """

    # Inicia el bucle principal de la interfaz gráfica (Tkinter)
    root.mainloop()

