.. module:: interfaz

.. _interfaz:

Módulo interfaz
---------------

Este módulo contiene la clase ``InventarioView``, Maneja la interfaz grafica y la interaccion con el controlador.

Clase InventarioView
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: InventarioView
   :members:
   :undoc-members:
   :show-inheritance:

   .. automethod:: __init__
