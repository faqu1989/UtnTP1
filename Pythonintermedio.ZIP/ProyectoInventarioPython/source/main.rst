.. _main:

Módulo main
-----------

Este módulo es el punto de entrada principal de la aplicación. Se encarga de inicializar los componentes necesarios (controlador, modelo, vista) y lanzar la interfaz gráfica de usuario (GUI).

.. automodule:: main
   :members:
   :undoc-members:


Aqui se realiza la implementacion de las clases de la siguiente forma :

.. code-block:: python

    # Definición del modelo (datos)
    model = InventarioModel()
    """
    .. autoclass:: InventarioModel
       :members:
       :undoc-members:
       :show-inheritance:
    """

    # Definición del controlador (lógica)
    controller = InventarioController(model)
    """
    .. autoclass:: InventarioController
       :members:
       :undoc-members:
       :show-inheritance:
    """

    # Definición de la vista (interfaz gráfica)
    view = InventarioView(root, controller)  # Pasa el controlador a la vista
    """
    .. autoclass:: InventarioView
       :members:
       :undoc-members:
       :show-inheritance:
    """


.. note::
   Este módulo no contiene clases, lo docuementado aqui es la implementacion incial de los componentes necesarios 