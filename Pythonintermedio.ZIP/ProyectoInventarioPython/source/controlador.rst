.. module:: controlador

.. _controlador:

Módulo controlador
------------------

Este módulo contiene la clase ``InventarioController``, que se encarga de la lógica  del sistema de inventario. Aqui se implementan los metodos ``__init__`` para
inicializar el controlador, asi como los metodos mas especificos como ``agregar_registro``,  ``modificar_registro``,``eliminar_registro``,
``consultar_registros``,``exportar_registros`` y ``get_registros``,

Clase InventarioController
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: InventarioController

   .. automethod:: __init__
   .. automethod:: agregar_registro
   .. automethod:: modificar_registro
   .. automethod:: eliminar_registro
   .. automethod:: consultar_registros
   .. automethod:: exportar_registros
   .. automethod:: get_registros
