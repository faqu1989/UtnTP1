.. module:: modelo

.. _modelo:

Módulo modelo
-------------

Este módulo contiene la clase ``InventarioModel``, que interactúa con la base de datos para gestionar los registros del inventario.

Clase InventarioModel
~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: InventarioModel
   :members:
   :undoc-members:
   :show-inheritance:
   
   .. automethod:: __init__
