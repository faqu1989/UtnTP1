.. ProyectoInventarioPython documentation master file, created by
   sphinx-quickstart on Sun Jul 21 18:39:54 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentación del Sistema de Inventario
=======================================

Este documento proporciona una descripción detallada del sistema de inventario, incluyendo sus módulos principales y sus funcionalidades.
Detallando en la funcionalidad de cada uno de los metodos implementados. Presiona en el modulo de interes para ver mas detalles 

.. toctree::
   :maxdepth: 2

   main

Este Modulo es el punto de entrada principal de la aplicación de inventario.
Esta sección se ejecuta cuando el script se llama directamente (no se importa como módulo).
Inicializa el modelo, la vista y el controlador, y luego inicia el bucle principal de la interfaz gráfica.

.. toctree::
   :maxdepth: 2

   controlador

Esta clase que maneja las operaciones de inventario, actuando como intermediario entre la interfaz de usuario y el modelo de datos.

.. toctree::
   :maxdepth: 2

   modelo

Aeui dse describe el modelo para gestionar el inventario en una base de datos SQLite.

.. toctree::
   :maxdepth: 2

   interfaz

Se describe la vista principal del sistema de inventario. Maneja la interfaz gráfica y la interacción con el controlador.

.. toctree::
   :maxdepth: 2

   respuesta

Esta clase representa la respuesta de una operación, incluyendo estado, errores y registros